#!/usr/bin/env python3
"""
run_submission.py -- single entry point for the BIRD submission run.

Configure exactly TWO things, then run  `python3 run_submission.py`:

  1. Your OpenAI key    -> OPENAI_API_KEY env var   (export OPENAI_API_KEY=...; or put it in .env)
  2. The test.json path -> submission_config.yaml   (`input:`)

It runs the full TRIAGE pipeline over the input question set and writes
BIRD-format predictions to `predict_out:` (default predictions/predict_test.json):

    { "<question_id>": "<predicted_sql>\\t----- bird -----\\t<db_id>", ... }

Resumable: re-running skips question_ids already completed (see bird/runs/).
No ground-truth SQL is read from the input; test.json's empty "SQL" fields are fine.
"""
from __future__ import annotations
import os
import sys
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent


def load_env(path: Path) -> None:
    """Minimal .env loader (KEY=VALUE). Does not overwrite already-set vars."""
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def load_config(path: Path) -> dict:
    """Minimal flat 'key: value' config parser (no PyYAML dependency)."""
    cfg: dict[str, str] = {}
    if not path.exists():
        return cfg
    for line in path.read_text().splitlines():
        line = line.split("#", 1)[0].strip()          # drop inline comments
        if not line or ":" not in line:
            continue
        k, _, v = line.partition(":")
        cfg[k.strip()] = v.strip().strip('"').strip("'")
    return cfg


def main() -> None:
    load_env(HERE / ".env")                                  # (1) keys
    cfg = load_config(HERE / "submission_config.yaml")       # (2) test.json path etc.

    inp     = cfg.get("input", "data/bird/test/test.json")
    out     = cfg.get("predict_out", "predictions/predict_test.json")
    db_dir  = cfg.get("db_dir", "data/bird/test/test_databases")
    backend = cfg.get("model_backend", "proxy")
    workers = cfg.get("workers", "12")

    inp_path = Path(inp) if os.path.isabs(inp) else (HERE / inp)
    out_path = Path(out) if os.path.isabs(out) else (HERE / out)
    db_path  = Path(db_dir) if os.path.isabs(db_dir) else (HERE / db_dir)

    if not inp_path.exists():
        sys.exit(f"[error] input file not found: {inp_path}\n"
                 f"        Place the official test.json there, or edit `input:` "
                 f"in submission_config.yaml.")
    if not db_path.exists():
        print(f"[warn] db_dir not found: {db_path}\n"
              f"       Place the test databases as <db_id>/<db_id>.sqlite there "
              f"(see data/bird/DATABASES.md); questions cannot be answered without them.",
              file=sys.stderr)

    env = os.environ.copy()
    env["MODEL_BACKEND"] = backend
    env.setdefault("MODEL_NAME", "Qwen/Qwen2.5-0.5B-Instruct")   # local backend only
    env.setdefault("MAX_TOKENS", "1500")
    env["BIRD_DB_DIR"] = str(db_path.resolve())
    env["EXEMPLAR_BANK"] = str(
        (HERE / "exemplar_bank" / "bird" / "contrastive_hard_bank_proxy.json").resolve())

    if backend == "proxy" and not env.get("OPENAI_API_KEY"):
        sys.exit("[error] proxy backend needs OPENAI_API_KEY set in the "
                 "environment (export OPENAI_API_KEY=...) or in .env")

    cmd = [sys.executable, "run_full_pipeline.py",
           "--input",   str(inp_path.resolve()),
           "--predict", str(out_path.resolve()),
           "--workers", str(workers)]
    print(f"[run] backend={backend}  model=gpt-5.6-luna\n"
          f"[run] input={inp_path}\n[run] db_dir={db_path}\n[run] predict_out={out_path}\n"
          f"[run] exemplar_bank={env['EXEMPLAR_BANK']}\n[run] {' '.join(cmd)}\n", flush=True)
    raise SystemExit(subprocess.call(cmd, cwd=str(HERE / "bird"), env=env))


if __name__ == "__main__":
    main()
