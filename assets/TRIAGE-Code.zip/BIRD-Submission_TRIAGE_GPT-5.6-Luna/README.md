# BIRD Submission — TRIAGE (multi-agent text-to-SQL)

Self-contained package to reproduce our BIRD results and run our system on the
held-out **test.json**. One method, one command.

**Method (per question, 12 LLM calls):**
```
schema predictor ─┐
10 error-specialist agents (S1–S10) ─┼─► execute each candidate ─► execution-feedback merger ─► final SQL
                                     ─┘        (over the predicted schema)
```
Few-shot demonstrations are contrastive (correct + plausible-incorrect + why),
retrieved cross-database from a generated *hard-question* bank. Our dev EX
(`predictions/predict_dev.json`) is **74.1%**.

---

## TL;DR — two things to configure, then one command

```bash
python3 -m pip install -r requirements.txt

# 1) KEY — set your OpenAI API key (used by the gpt-5.6-luna proxy backend)
export OPENAI_API_KEY="your_key"
#    (alternatively: cp .env.example .env  and put OPENAI_API_KEY=... in .env)

# 2) TEST SET — put the official files where submission_config.yaml points:
#      data/bird/test/test.json                          (questions)
#      data/bird/test/test_databases/<db>/<db>.sqlite    (databases; see data/bird/DATABASES.md)

python3 run_submission.py
```

Output: BIRD-format predictions at `predictions/predict_test.json`:
```json
{ "0": "SELECT ... \t----- bird -----\t <db_id>", "1": "...", ... }
```

Everything is driven by the **`OPENAI_API_KEY`** env var (key) and
**`submission_config.yaml`** (paths). Nothing else needs editing. The model is
fixed to **`gpt-5.6-luna`** (OpenAI Responses API) — there is no model option.

### `submission_config.yaml`
```yaml
input:         data/bird/test/test.json            # the test questions
db_dir:        data/bird/test/test_databases       # the test databases
predict_out:   predictions/predict_test.json       # where predictions go
model_backend: proxy                               # proxy | local
workers:       12
```
Paths may be relative (to this folder) or absolute.

---

## Environment
- **Python** 3.9+; deps in [`requirements.txt`](requirements.txt)
  (`openai`, `sentence-transformers`, `sqlglot`, `tqdm`, `numpy`, `torch`).
- **No GPU / CUDA / Java required** for the default **proxy** backend (all
  generation is via the hosted API). CUDA (12.2/12.3) is only relevant if you
  switch to the optional `local` HuggingFace backend.
- First run builds a small retrieval-embedding cache under `bird/cache/`
  (auto-generated from the bundled `train`/`hard` pools; a few minutes, once).

## Providing model access (keys)
The default `proxy` backend calls the OpenAI Responses API with the model
`gpt-5.6-luna`. Provide your OpenAI API key via the `OPENAI_API_KEY`
environment variable:
```bash
export OPENAI_API_KEY="your_key"
```
(or put `OPENAI_API_KEY=...` in a `.env` file — it is git-ignored; only
`.env.example` ships, empty). No keys are committed to this package.

## `column_meaning.json`
**Not required.** The pipeline uses only `test.json`, the schema from
`*_tables.json`, the per-question `evidence` field, and (if present) BIRD's
`database_description/*.csv`. It does not read `column_meaning.json`.

## Ground truth / rules compliance
- **No ground truth is read.** `test.json`'s empty `"SQL"` fields are expected;
  in test mode scoring is skipped and only predictions are emitted.
- **No database exfiltration.** The only external call is the LLM chat API you
  configure; databases are opened locally, **read-only**, and never uploaded.
- Reproducible/resumable (below).

## Logging & resumability
Per-question records stream to `bird/runs/4.8/full_pipeline_all_hard_fewshot.jsonl`
as they complete. Re-running **skips question_ids already on disk**, so an
interrupted run resumes from where it stopped rather than restarting. If a
question errored (recorded with `"error"` and an empty SQL), delete that line
and re-run to retry just that question.

## Dev predictions (included)
`predictions/predict_dev.json` — our predicted SQLs on the BIRD **dev** set
(1,534 questions, EX **74.1%**), in the same BIRD format.

---

## What's in this package
```
BIRD-Submission/
  run_submission.py        # single entry point (reads .env + submission_config.yaml)
  submission_config.yaml   # paths + backend/model
  .env.example             # empty key template (copy to .env)
  requirements.txt
  model.py                 # LLM backend (proxy | local)
  bird/                    # the pipeline: schema predictor, 10 specialists, merger
  exemplar_bank/bird/      # contrastive hard-question bank (used for few-shot)
  data/bird/               # dev.json + *_tables.json + train/hard pools + schema graphs
                           #   (DATABASES excluded — see data/bird/DATABASES.md)
  predictions/             # predict_dev.json (ours); predict_test.json (produced by a run)
```

## Verify the setup (smoke test)
No databases ship with this package. To confirm the pipeline runs end-to-end,
place any one BIRD **dev** database (e.g. `superhero`) at
`data/bird/dev/dev_databases/superhero/superhero.sqlite`, then:
```bash
cd bird
python3 run_full_pipeline.py --db superhero --limit 2 --workers 12
```
(runs 2 bundled dev questions against that DB; prints EX and writes predictions).

## Direct invocation (equivalent to run_submission.py)
```bash
cd bird
BIRD_DB_DIR=/abs/path/to/test_databases \
python3 run_full_pipeline.py \
  --input /abs/path/to/test.json \
  --predict /abs/path/to/predict_test.json \
  --workers 12
```
(the key is read from the environment / `.env`; the model is fixed to
`gpt-5.6-luna`).

## Contact
BIRD organizers: `bird.bench23@gmail.com`.
