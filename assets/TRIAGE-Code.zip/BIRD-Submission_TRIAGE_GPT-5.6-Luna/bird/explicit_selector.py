"""
explicit_selector.py — Deterministic, zero-LLM-call gating for the Phase 4
specialist pipeline, mirroring the pattern in run_heldout_with_explicit_selector.py
(that script's own docstring: "the default pipeline calls all N specialists on
every query, even when most are irrelevant... a deterministic, query-driven
selector that runs ONLY the skills a query plausibly needs").

Two independent gates, both NL-question-side only (no gold SQL, no join
count from a parsed query - those aren't available at real inference time,
unlike generation/select_hard_train.py's join-count heuristic which needs
gold SQL and is only usable for offline dataset curation):

  is_easy(question)     EASY GUARD - structurally simple questions (few
                         entities, no aggregation/relational language) skip
                         the entire 6-specialist + merger pipeline and get a
                         single zero-shot call instead. New capability, not
                         present in the AEP reference script.

  select_skills(question)  EXPLICIT SELECTOR - for everything that isn't
                         easy-guarded, picks the subset of S1-S6 whose
                         target failure category the question's wording
                         plausibly triggers, instead of always running all 6.
                         S1 (aggregation/DISTINCT) and S2 (literal matching)
                         are MANDATORY - together they cover 80.6% of mined
                         failures (generation/taxonomy_clusters.json), so
                         skipping them is never worth the call savings.
"""

from __future__ import annotations

import re

# ── Easy guard ────────────────────────────────────────────────────────────────
# Deliberately conservative: only questions with a single clear entity/filter
# and no aggregation/relational/superlative language get guarded. Matches the
# project's own "Easy: <=1 JOIN, simple WHERE filters" hardness definition
# (judge/build_schema_prompts.py's HARDNESS LEVELS section) - approximated
# here from question wording alone, since gold SQL isn't available at
# inference time to actually count joins.
_MULTI_ENTITY_HINTS = [
    # standalone relative-clause words, not just "and...who/that/which" - a
    # false "easy" is the real risk here, so cast this net wide. Caught by a
    # smoke check against real dev questions: "Name chemical elements THAT
    # form a bond..." and "the patient WHO ... was diagnosed with PSS and..."
    # both have the clause word appear BEFORE any "and", or with no "and" at
    # all, so requiring "and" first as this list previously did missed them.
    r"\bwho\b", r"\bthat\b", r"\bwhich\b",
    r"\bthrough\b", r"\bvia\b",
    r"\bassociated with\b", r"\blinked to\b", r"\bconnected to\b",
]
_COMPLEXITY_SIGNALS = [
    r"\bhow many\b", r"\bnumber of\b", r"\bcount\b", r"\btotal\b",
    r"\baverage\b", r"\bsum\b", r"\bpercent", r"\bratio\b",
    r"\bdistinct\b", r"\bunique\b", r"\bper\b", r"\beach\b",
    r"\bhighest\b", r"\blowest\b", r"\bmost\b", r"\bleast\b", r"\btop\b",
    r"\boldest\b", r"\byoungest\b", r"\bnewest\b", r"\blatest\b", r"\bearliest\b",
    r"\bmore than\b", r"\bless than\b", r"\bat least\b", r"\bbetween\b",
    r"\b(19|20)\d{2}\b",  # a specific year/date implies a filter + likely a
                          # derived computation (e.g. "finishing rate on
                          # <date>"), not a trivial single-column lookup -
                          # keep this in sync with SELECTOR_SIGNALS["S4"]
]
_COMPLEXITY_PATTERNS = [re.compile(p, re.I) for p in _COMPLEXITY_SIGNALS]
_MULTI_ENTITY_PATTERNS = [re.compile(p, re.I) for p in _MULTI_ENTITY_HINTS]


def is_easy(question: str) -> bool:
    """True if the question shows none of the complexity/multi-entity
    signals above - i.e. it plausibly needs only a simple single-table
    filter/lookup, not the full specialist pipeline. Deterministic, no LLM
    call. Conservative by construction: a false "not easy" just costs the
    full pipeline anyway (safe); a false "easy" is the only real risk, which
    is why the signal lists above are broad rather than narrow."""
    q = question.lower()
    if any(p.search(q) for p in _COMPLEXITY_PATTERNS):
        return False
    if any(p.search(q) for p in _MULTI_ENTITY_PATTERNS):
        return False
    return True


# ── Explicit selector ─────────────────────────────────────────────────────────
MANDATORY = ["S1", "S2"]  # aggregation/DISTINCT + literal matching: 80.6% of mined failures

SELECTOR_SIGNALS: dict[str, list[str]] = {
    # S3 - Wrong Column / Join-Path Shortcut: indirect/derived-entity phrasing
    "S3": [r"\bthrough\b", r"\bvia\b", r"\bcapital of\b", r"\bcode\b",
           r"\bcontaining\b", r"\blocated in\b", r"\bbelongs to\b",
           r"\bbelonging to\b"],
    # S4 - Temporal & Superlative Interpretation
    "S4": [r"\boldest\b", r"\byoungest\b", r"\bnewest\b", r"\blatest\b",
           r"\bearliest\b", r"\bmost recent\b", r"\bcurrent\b", r"\bactive\b",
           r"\b(19|20)\d{2}\b", r"\bdate\b", r"\byear\b", r"\bsince\b",
           r"\bbefore\b", r"\bafter\b"],
    # S5/S6 - Missing/Extra JOIN: relational connectors implying >=2 entities
    "S5": [r"\bwho\b", r"\bthat\b", r"\bwhich\b", r"\bassociated with\b",
           r"\blinked to\b", r"\bconnected to\b"],
    "S6": [r"\bwho\b", r"\bthat\b", r"\bwhich\b", r"\bassociated with\b",
           r"\blinked to\b", r"\bconnected to\b", r"\bsame\b", r"\bboth\b"],
    # S7 - Subquery / nesting structure: comparisons to an aggregate/other set
    "S7": [r"\bthan the\b", r"\baverage\b", r"\bmore than\b", r"\bless than\b",
           r"\bat least\b", r"\bcompared\b", r"\bthan any\b", r"\bthan all\b",
           r"\babove\b", r"\bbelow\b", r"\balso\b"],
    # S8 - NULL / empty-result / active-record semantics
    "S8": [r"\bnull\b", r"\bmissing\b", r"\bwithout\b", r"\bdo not\b",
           r"\bdoes not\b", r"\bblank\b", r"\bempty\b", r"\bunknown\b",
           r"\bcurrent\b", r"\bactive\b", r"\bstill\b"],
    # S9 - String / LIKE / pattern & case matching
    "S9": [r"\bcontain", r"\bstart", r"\bend", r"\bbegin", r"\binclude",
           r"\bmention", r"\bcalled\b", r"\bkeyword\b", r"\bsubstring\b"],
    # S10 - Ordering / ranking / ties & LIMIT
    "S10": [r"\btop\b", r"\bbottom\b", r"\bfirst\b", r"\blast\b", r"\bhighest\b",
            r"\blowest\b", r"\bmost\b", r"\bleast\b", r"\brank", r"\border",
            r"\bgreatest\b", r"\bsmallest\b", r"\bmaximum\b", r"\bminimum\b"],
}
_SEL_PATTERNS = {sn: [re.compile(p, re.I) for p in pats]
                 for sn, pats in SELECTOR_SIGNALS.items()}

CANONICAL_ORDER = ["S1", "S2", "S3", "S4", "S5", "S6", "S7", "S8", "S9", "S10"]


def select_skills(question: str) -> list[str]:
    """Returns the subset of S1-S6 to run for this question (in canonical
    order). Deterministic, no LLM call. S1+S2 always included."""
    q = question.lower()
    sel = set(MANDATORY)
    for sn, pats in _SEL_PATTERNS.items():
        if any(p.search(q) for p in pats):
            sel.add(sn)
    return [sn for sn in CANONICAL_ORDER if sn in sel]
