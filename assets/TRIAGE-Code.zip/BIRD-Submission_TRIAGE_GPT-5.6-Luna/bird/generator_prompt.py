"""
generator_prompt.py — Shared SQL-generator prompt assembly for Phases 1/3/4.

Distinct from judge/build_schema_prompts.py, which builds an AUDITOR prompt
("judge whether this SQL is correct"). This builds a GENERATOR prompt ("write
SQL for this question") - same schema/FK/hop-path rendering (data_bird/
schema_utils.py), different task framing.

Used by:
  - judge/build_proxy_hard_bank.py     (one-time hard-pool zero-shot bank)
  - generation/run_phase1_baseline.py  (zero-shot floor, gold-few-shot ceiling)
  - generation/run_phase3_fewshot_ladder.py (skeleton / proxy / contrastive)
  - generation/run_phase4_specialists.py    (per-specialist generation)
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from schema_utils import (  # noqa: E402
    load_schema_graphs, render_foreign_keys, render_hop_paths, render_schema,
)

_SCHEMA_GRAPHS = load_schema_graphs()  # loaded once; only the 11 dev-side dbs have an entry


def build_generator_system_prompt(db_id: str, entry: dict, db_dir: "Path | None",
                                   extra_instructions: str = "",
                                   profiles: "dict | None" = None) -> str:
    """extra_instructions: appended after the base task spec - used by Phase 4
    specialists to add their own focus area without duplicating schema
    rendering. profiles: optional per-column value profiles (generation/
    profiling.py) rendered inline into the schema."""
    schema_str = render_schema(entry, db_dir, profiles)
    fk_str = render_foreign_keys(entry)
    hop_str = render_hop_paths(db_id, _SCHEMA_GRAPHS)
    base = f"""You are an expert SQLite SQL generator for the database "{db_id}".

--- DATABASE SCHEMA -----------------------------------------------------------

{schema_str}

--- FOREIGN KEYS --------------------------------------------------------------

{fk_str}

--- JOIN GRAPH / MULTI-HOP PATHS ----------------------------------------------

{hop_str}

--- YOUR TASK ---------------------------------------------------------------

Given the natural-language question below (and an optional Hint, which is
authoritative if present), write a single valid SQLite SELECT query that
answers it.

Think step by step inside <reasoning> tags: identify the entities, filters,
and aggregations the question requires; the correct join path (using the
foreign keys / hop paths above); and any hint-specified formula or literal.
Then output the final query inside <sql> tags - the SQL must be the ONLY
content inside <sql>...</sql> (no explanation, no markdown fences, no
leading "SQL:" label).

<reasoning>
...
</reasoning>
<sql>
...
</sql>"""
    if extra_instructions:
        base += f"\n\n{extra_instructions}"
    return base


def build_merger_system_prompt(db_id: str, entry: dict, db_dir: "Path | None",
                                merger_task: str, profiles: "dict | None" = None) -> str:
    """Merger system prompt with the SAME grounding the specialists get -
    full schema, foreign keys, and multi-hop join paths for this question's
    database - followed by the merger task spec (merger_task). Lets the merger
    verify each candidate against the real schema/joins rather than picking
    blind from SQL strings alone. profiles: optional per-column value profiles
    rendered inline into the schema."""
    schema_str = render_schema(entry, db_dir, profiles)
    fk_str = render_foreign_keys(entry)
    hop_str = render_hop_paths(db_id, _SCHEMA_GRAPHS)
    return f"""You are an expert SQLite SQL merger for the database "{db_id}".

--- DATABASE SCHEMA -----------------------------------------------------------

{schema_str}

--- FOREIGN KEYS --------------------------------------------------------------

{fk_str}

--- JOIN GRAPH / MULTI-HOP PATHS ----------------------------------------------

{hop_str}

--- YOUR TASK ---------------------------------------------------------------

{merger_task}"""


def build_generator_user_message(question: str, evidence: str = "",
                                  examples_block: str = "") -> str:
    """examples_block, if given, is prepended verbatim (already fully
    rendered - header + exemplars + separator) ahead of the question."""
    tail = f"Question: {question}"
    if evidence:
        tail += f"\nHint: {evidence}"
    if examples_block:
        return f"{examples_block}\n\n{tail}"
    return tail


def clean_sql(raw: str) -> str:
    """Extracts the final SQL from a raw model reply: pulls the contents of
    <sql>...</sql> if present (the CoT format above), otherwise falls back to
    stripping markdown fences / a leading 'SQL:' label from the whole reply
    (covers non-CoT callers, e.g. Phase 4 specialists/merger, which don't use
    the <reasoning>/<sql> format)."""
    text = raw.strip()
    m = re.search(r"<sql>(.*?)</sql>", text, re.DOTALL | re.IGNORECASE)
    if m:
        text = m.group(1)
    text = text.strip()
    text = re.sub(r"^```sql\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"^```\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    text = re.sub(r"^SQL:\s*", "", text, flags=re.IGNORECASE)
    return text.strip()
