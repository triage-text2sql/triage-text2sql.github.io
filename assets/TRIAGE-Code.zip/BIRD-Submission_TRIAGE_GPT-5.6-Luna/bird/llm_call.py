"""
llm_call.py — thin shim so the copied BIRD pipeline code can keep doing
`from llm_call import AsyncCaller, gather_with_progress` unchanged. All real
logic (proxy vs. local backend switch) lives in the package-root model.py.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from model import AsyncCaller, gather_with_progress  # noqa: E402,F401
