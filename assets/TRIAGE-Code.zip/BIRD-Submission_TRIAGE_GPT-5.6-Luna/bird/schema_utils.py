"""
Shared schema/hop-graph rendering for BIRD, used by both judge/build_schema_prompts.py
and prompts/build_schema_prompts.py so the two don't duplicate the same
table/column/foreign-key/hop-path rendering logic.

Data sources (all already in this repo):
  train/train_tables.json, dev/dev_tables.json
      Spider/BIRD schema format: table_names_original, column_names_original
      ([table_idx, col_name], -1 = wildcard), column_types, primary_keys,
      foreign_keys ([col_idx, col_idx] pairs).
  {train,dev}/{train,dev}_databases/<db_id>/database_description/*.csv
      Per-column descriptions (original_column_name, column_description,
      value_description). Present for both train and dev databases.
  schema_graphs.json
      Precomputed multi-hop join-path enumeration, but ONLY for the 11
      databases that are also the dev-set databases (verified: dev and train
      db_id sets are disjoint, 69 train + 11 dev = 80 total). The other 69
      databases have no entry here and fall back to the foreign_keys list.
"""

import csv
import json
from pathlib import Path

DATA_BIRD = Path(__file__).resolve().parent.parent / "data" / "bird"
TRAIN_TABLES = DATA_BIRD / "train" / "train_tables.json"
DEV_TABLES = DATA_BIRD / "dev" / "dev_tables.json"
TRAIN_DB_DIR = DATA_BIRD / "train" / "train_databases"
DEV_DB_DIR = DATA_BIRD / "dev" / "dev_databases"
SCHEMA_GRAPHS_PATH = DATA_BIRD / "schema_graphs.json"


def load_schema_graphs() -> dict:
    if not SCHEMA_GRAPHS_PATH.exists():
        return {}
    return json.loads(SCHEMA_GRAPHS_PATH.read_text())


def iter_all_schemas():
    """Yield (db_id, table_entry, db_dir_or_None) for all 80 databases."""
    for entries, db_root in (
        (json.loads(TRAIN_TABLES.read_text()), TRAIN_DB_DIR),
        (json.loads(DEV_TABLES.read_text()), DEV_DB_DIR),
    ):
        for entry in entries:
            db_id = entry["db_id"]
            db_dir = db_root / db_id
            yield db_id, entry, (db_dir if db_dir.exists() else None)


def load_column_descriptions(db_dir: "Path | None", table_name_original: str) -> dict:
    """original_column_name -> best-available description, or {} if absent."""
    if db_dir is None:
        return {}
    csv_path = db_dir / "database_description" / f"{table_name_original}.csv"
    if not csv_path.exists():
        return {}
    out = {}
    with csv_path.open(encoding="utf-8-sig", errors="replace", newline="") as f:
        for row in csv.DictReader(f):
            col = (row.get("original_column_name") or "").strip()
            if not col:
                continue
            desc = " ".join((row.get("column_description") or "").split())
            val_desc = " ".join((row.get("value_description") or "").split())
            text = " | ".join(p for p in (desc, val_desc) if p)
            if text:
                out[col] = text
    return out


def _profile_note(profiles: "dict | None", table: str, col: str) -> str:
    """Inline value-profile annotation for one column (self-contained; the
    profile dict is {table.col: {distinct, format, top_values, ...}} from
    generation/profiling.py). Empty when no profile is supplied."""
    if not profiles:
        return ""
    p = profiles.get(f"{table}.{col}")
    if not p:
        return ""
    bits = []
    if p.get("distinct") is not None:
        bits.append(f"{p['distinct']} distinct")
    if p.get("format"):
        bits.append(f"format {p['format']}")
    tv = p.get("top_values") or []
    if tv:
        bits.append("e.g. " + ", ".join(repr(v) for v in tv[:5]))
    return "  [" + "; ".join(bits) + "]" if bits else ""


def render_schema(entry: dict, db_dir: "Path | None", profiles: "dict | None" = None) -> str:
    tables = entry["table_names_original"]
    cols = entry["column_names_original"]
    types = entry["column_types"]
    pk_flat = set()
    for pk in entry.get("primary_keys", []):
        pk_flat.update(pk if isinstance(pk, list) else [pk])

    by_table: dict = {i: [] for i in range(len(tables))}
    for col_idx, (t_idx, col_name) in enumerate(cols):
        if t_idx == -1:
            continue
        by_table[t_idx].append((col_idx, col_name))

    parts = []
    for t_idx, table in enumerate(tables):
        col_desc = load_column_descriptions(db_dir, table)
        lines = [f"TABLE {table}"]
        for col_idx, col_name in by_table[t_idx]:
            col_type = types[col_idx] if col_idx < len(types) else "unknown"
            marker = " [PK]" if col_idx in pk_flat else ""
            desc = col_desc.get(col_name, "")
            line = f"  - {col_name} ({col_type}){marker}"
            if desc:
                line += f" -- {desc}"
            line += _profile_note(profiles, table, col_name)
            lines.append(line)
        parts.append("\n".join(lines))
    return "\n\n".join(parts)


def render_foreign_keys(entry: dict) -> str:
    tables = entry["table_names_original"]
    cols = entry["column_names_original"]
    fks = entry.get("foreign_keys", [])
    if not fks:
        return "(no foreign keys declared for this schema)"
    lines = []
    for col_a, col_b in fks:
        ta, na = cols[col_a]
        tb, nb = cols[col_b]
        lines.append(f"  {tables[ta]}.{na} = {tables[tb]}.{nb}")
    return "\n".join(lines)


def render_hop_paths(db_id: str, schema_graphs: dict) -> str:
    g = schema_graphs.get(db_id)
    if not g:
        return ("(no precomputed multi-hop path enumeration for this database - "
                "infer multi-hop joins by chaining the foreign keys above)")
    edges = g["graph"]["directed_edges"]
    lines = ["Direct table links (from the join graph):"]
    for a, b in edges:
        lines.append(f"  {a} -- {b}")
    paths_by_len = g.get("paths_by_length", {})
    if paths_by_len:
        lines.append("\nMulti-hop paths (by number of hops):")
        for length, paths in sorted(paths_by_len.items(), key=lambda kv: int(kv[0])):
            for p in paths[:20]:  # cap for prompt length
                lines.append(f"  ({length}-hop) " + " -> ".join(p))
    return "\n".join(lines)
