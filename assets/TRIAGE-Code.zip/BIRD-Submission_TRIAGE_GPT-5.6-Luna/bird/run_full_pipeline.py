"""
run_full_pipeline_all_hard_fewshot.py — Same as run_full_pipeline_all_train_fewshot.py
(fully fresh: all 10 specialists (S1-S10) + schema-predictor + execution-
feedback merger, no cache reuse), but the few-shot given to EVERY specialist
AND the merger is now ALL cross-db HARD (5 nearest hard-pool exemplars from
OTHER databases, contrastive-proxy rendering with each exemplar's own schema),
instead of the mixed 3h+2t or train-only 5t blocks. This completes the grid
over {exemplar source} for all agents:

  - all_mixed_fewshot:  specialists + merger get 3 hard + 2 train
  - all_train_fewshot:  specialists + merger get 5 train, 0 hard
  - all_hard_fewshot:   specialists + merger get 5 cross-db hard, 0 train  <-- THIS

The exemplar block is exactly run_full_pipeline_fresh.py's specialist path
(retrieve_hard_cross_db + build_contrastive_block, include_schema=True), reused
for BOTH specialists and merger.

The schema-predictor's own few-shot (5 cross-db train, for predicting the
schema itself) is untouched - a separate, already-established mechanism.

Running this with the rich schema also produces the ONLY cached 10-agent
cross-db-hard candidate set (fresh.py was slim-schema and discarded its
candidates), enabling future cheap merger-only reruns.

Cost: 10 specialists + 1 predictor + 1 merger = 12 calls/question x 1,534 =
18,408 calls, same scale as the sibling runs.

Resumable: each question's record is written the moment it finishes; a re-run
skips question_ids already on disk (same --n/--seed => same sample).

Usage:
  python3 run_full_pipeline_all_hard_fewshot.py --n 1534 --seed 0 \
      --workers 12 --concurrent-questions 1
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import random
import sys
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
for p in ("generation", "judge", "data_bird"):
    sys.path.insert(0, str(ROOT / p))
sys.path.insert(0, str(HERE))

from generator_prompt import clean_sql                                       # noqa: E402
from schema_utils import iter_all_schemas                                    # noqa: E402
from llm_call import AsyncCaller                                             # noqa: E402
from retrieval import Retriever                                              # noqa: E402
from selector_tier1 import _connect, result_signature                        # noqa: E402
from run_phase4_specialists import (SPECIALISTS, run_specialists,            # noqa: E402
                                     build_contrastive_block, CONTRASTIVE_PROXY_BANK_PATH, K_HARD)
from exec_feedback_pilot import EXEC_MERGER_TASK, build_merger_msg, _preview  # noqa: E402
from run_oracle_merger_pilot import filter_entry_to_oracle                    # noqa: E402
from run_schema_predictor_extrinsic import build_predicted_merger_system_prompt, add_fk_safety_net  # noqa: E402
from run_schema_predictor_intrinsic import build_predictor_messages, parse_prediction  # noqa: E402

DEV_PATH = ROOT / "data" / "bird" / "dev" / "dev.json"
OUT_PATH = HERE / "runs" / "4.8" / "full_pipeline_all_hard_fewshot.jsonl"
K_PREDICTOR_TRAIN = 5   # schema-predictor's OWN few-shot (unchanged)
# K_HARD (=5) imported from run_phase4_specialists: cross-db hard exemplars
# given to specialists AND merger.


def score_against_gold(db_id: str, gold_sql: str, sql: str) -> bool:
    con = _connect(db_id)
    try:
        gold = result_signature(con, gold_sql)
        got = result_signature(con, sql)
        if gold is None or got is None:
            return False
        return got == gold
    finally:
        con.close()


def build_hard_examples(retriever, contrastive, schemas, question: str, db_id: str) -> str:
    """Cross-db hard exemplar block (5 nearest hard-pool exemplars from OTHER
    databases), used for BOTH specialists and the merger in this experiment.
    Same construction as run_full_pipeline_fresh.py's specialist path: each
    exemplar carries its own schema (include_schema=True) so cross-database SQL
    is interpretable, rendered as contrastive-proxy correct+incorrect pairs."""
    hard_ex = retriever.retrieve_hard_cross_db(question, db_id, k=K_HARD)
    return build_contrastive_block(hard_ex, contrastive, schemas=schemas, include_schema=True)


async def _amain(n: int, seed: int, workers: int,
                  concurrent_questions: int, db: "str | None" = None,
                  limit: "int | None" = None, input_path: "str | None" = None,
                  predict_path: "str | None" = None):
    # Input set: BIRD dev.json by default, or a caller-provided file (e.g. the
    # official test.json, whose "SQL" fields are empty). --input / $BIRD_INPUT.
    src = Path(input_path or os.environ.get("BIRD_INPUT") or DEV_PATH)
    print(f"[input] {src}", flush=True)
    dev_list = json.loads(src.read_text())
    # Optional db filter (e.g. --db superhero) so a run/smoke targets only the
    # dev databases whose .sqlite files are actually present under
    # data/bird/dev/dev_databases/.
    if db:
        dev_list = [r for r in dev_list if r["db_id"] == db]
        if not dev_list:
            raise SystemExit(f"[error] no dev questions for db_id={db!r}")
    random.seed(seed)
    if limit is not None:
        # Deterministic first-`limit` questions (after the db filter) — used by
        # the 2-question smoke; avoids sampling into databases with no DB file.
        sample = dev_list[:limit]
    else:
        sample = random.sample(dev_list, min(n, len(dev_list)))

    schemas = {db: (e, dd) for db, e, dd in iter_all_schemas()}
    retriever = Retriever()
    contrastive = json.loads(CONTRASTIVE_PROXY_BANK_PATH.read_text())
    caller = AsyncCaller(max_concurrency=workers, max_tokens=1500)
    predictor_caller = AsyncCaller(max_concurrency=workers, max_tokens=1200)

    # ---- specialists (CROSS-DB HARD fewshot) + schema-predictor (own train fewshot) ----
    async def _generate(row: dict):
        db_id = row["db_id"]
        entry, db_dir = schemas[db_id]

        specialist_examples = build_hard_examples(retriever, contrastive, schemas,
                                                    row["question"], db_id)

        q_emb = retriever.embedder.encode([row["question"]], convert_to_tensor=True,
                                           normalize_embeddings=True)[0]
        train_exemplars = retriever.train_pool.top_k(q_emb, K_PREDICTOR_TRAIN,
                                                      exclude_exact=row["question"])
        psysp, puser = build_predictor_messages(row, entry, db_dir, train_exemplars, schemas)

        candidates, praw = await asyncio.gather(
            run_specialists(row, entry, db_dir, caller, examples_block=specialist_examples),
            predictor_caller([{"role": "system", "content": psysp}, {"role": "user", "content": puser}]))
        pred = parse_prediction(praw)
        return candidates, pred

    # ---- execution-feedback merger, predicted schema, CROSS-DB HARD fewshot ----
    async def _merge(row: dict, candidates: list, pred: dict):
        db_id = row["db_id"]
        entry, _db_dir = schemas[db_id]

        pred_tables = set(pred["tables"])
        pred_cols_by_table = defaultdict(set)
        for t, c in pred["columns"]:
            pred_cols_by_table[t].add(c)
            pred_tables.add(t)
        pred_cols_by_table = add_fk_safety_net(entry, pred_tables, dict(pred_cols_by_table))
        filtered_entry = filter_entry_to_oracle(entry, pred_tables, pred_cols_by_table) or entry

        con = _connect(db_id)
        try:
            cand_prev = []
            for c in candidates:
                status, _ = _preview(con, c["sql"])
                cand_prev.append({"id": c["id"], "name": c.get("name", ""), "sql": c["sql"],
                                   "reasoning": (c.get("reasoning") or "")[:400], "result": status})
        finally:
            con.close()

        hard_examples = build_hard_examples(retriever, contrastive, schemas, row["question"], db_id)

        merger_rec = {"question": row["question"], "evidence": row.get("evidence", ""),
                       "candidates": cand_prev}
        user_msg = build_merger_msg(merger_rec, hard_examples)
        sysp = build_predicted_merger_system_prompt(db_id, filtered_entry, EXEC_MERGER_TASK)

        raw = await caller([{"role": "system", "content": sysp}, {"role": "user", "content": user_msg}])
        predicted_schema = {"tables": sorted(pred_tables),
                             "columns": sorted(f"{t}.{c}" for t, c in pred["columns"])}
        return clean_sql(raw), cand_prev, predicted_schema

    # One question end-to-end: 10 specialists (parallel) -> predictor -> merger
    # -> score, then write the full record. Concurrency lives INSIDE a question
    # (the generate burst), bounded across questions by q_sem so we don't
    # scatter one question's calls behind thousands of others (which starved the
    # old launch-all model). All intermediates are saved.
    async def _process(row: dict) -> dict:
        try:
            candidates, pred = await _generate(row)
            merged_sql, cand_prev, predicted_schema = await _merge(row, candidates, pred)
            # Test mode: test.json has empty "SQL" -> no gold, so skip scoring
            # (correct=None) and just emit the prediction.
            gold = (row.get("SQL") or "").strip()
            ok = score_against_gold(row["db_id"], gold, merged_sql) if gold else None
            return {"question_id": row["question_id"], "db_id": row["db_id"],
                    "difficulty": row.get("difficulty"),
                    "candidates": cand_prev, "predicted_schema": predicted_schema,
                    "merged_sql": merged_sql, "correct": ok}
        except Exception as e:
            return {"question_id": row["question_id"], "db_id": row["db_id"],
                    "difficulty": row.get("difficulty"),
                    "candidates": [], "predicted_schema": None,
                    "merged_sql": "", "correct": False, "error": str(e)[:200]}

    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    done_ids = set()
    if OUT_PATH.exists():
        with OUT_PATH.open() as f:
            for line in f:
                if line.strip():
                    done_ids.add(json.loads(line)["question_id"])
    todo = [r for r in sample if r["question_id"] not in done_ids]
    print(f"[full-pipeline-all-hard] {len(SPECIALISTS)} specialists (full schema, CROSS-DB HARD "
          f"fewshot: {K_HARD} hard) + schema-predictor + execution-feedback merger "
          f"({len(SPECIALISTS)+2} calls/question)")
    print(f"  {len(sample)} total, {len(done_ids)} already done, {len(todo)} to run; "
          f"concurrent_questions={concurrent_questions}, workers={workers}", flush=True)

    if todo:
        from tqdm import tqdm
        q_sem = asyncio.Semaphore(concurrent_questions)
        write_lock = asyncio.Lock()
        with OUT_PATH.open("a") as f, tqdm(total=len(todo), desc="full-pipeline", ncols=80) as bar:
            async def _run_one(row):
                async with q_sem:
                    rec = await _process(row)
                async with write_lock:
                    f.write(json.dumps(rec) + "\n")
                    f.flush()
                    bar.update(1)
            await asyncio.gather(*[_run_one(r) for r in todo])

    rows = [json.loads(l) for l in OUT_PATH.read_text().splitlines() if l.strip()]
    n_total = len(rows)
    n_err = sum(1 for r in rows if r.get("error"))

    # --- write BIRD-format predictions:  {qid: "<sql>\t----- bird -----\t<db_id>"} ---
    predict = {str(r["question_id"]): f'{r["merged_sql"]}\t----- bird -----\t{r["db_id"]}'
               for r in rows}
    ppath = Path(predict_path or os.environ.get("BIRD_PREDICT")
                 or OUT_PATH.with_name("predict.json"))
    ppath.parent.mkdir(parents=True, exist_ok=True)
    ppath.write_text(json.dumps(predict, indent=2))

    print(f"\n=== Full pipeline, {len(SPECIALISTS)} specialists (CROSS-DB HARD fewshot) "
          f"+ schema-predictor + execution-feedback merger  (N={n_total}) ===")
    # Score only when gold was available (dev). On test.json (no gold) correct=None.
    scored = [r for r in rows if r.get("correct") is not None]
    if scored:
        n_ok = sum(int(r["correct"]) for r in scored)
        print(f"  EX: {n_ok/len(scored):.1%}  ({n_ok}/{len(scored)})")
        by_diff = defaultdict(lambda: [0, 0])
        for r in scored:
            d = r.get("difficulty") or "unknown"
            by_diff[d][0] += int(r["correct"]); by_diff[d][1] += 1
        print("  by difficulty:")
        for d in sorted(by_diff):
            c, t = by_diff[d]
            print(f"    {d:12s} n={t:4d}  {c/t:.1%}")
    else:
        print("  (test mode: no gold SQL in input -> EX not computed)")
    if n_err:
        print(f"  WARNING: {n_err} question(s) recorded an error (merged_sql=''). "
              f"Delete those lines from the results jsonl and re-run to retry just them.")
    print(f"\nwrote results   -> {OUT_PATH}")
    print(f"wrote predictions -> {ppath}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=1534)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--workers", type=int, default=12,
                     help="max concurrent LLM calls (per AsyncCaller); 12 lets one "
                          "question's 11-call generate burst run fully in parallel")
    ap.add_argument("--concurrent-questions", type=int, default=1,
                     help="how many questions to process end-to-end at once; 1 = strictly "
                          "one at a time (finish final SQL before starting the next)")
    ap.add_argument("--db", default=None,
                     help="restrict to a single dev db_id (needs its .sqlite present under "
                          "data/bird/dev/dev_databases/<db>/). Used by the smoke test.")
    ap.add_argument("--limit", type=int, default=None,
                     help="take the first N questions (after --db filter), deterministically, "
                          "instead of a random sample of --n. Used by the smoke test.")
    ap.add_argument("--input", default=None,
                     help="path to the question set to run (default: bundled dev.json). "
                          "Point this at the official test.json for a submission run.")
    ap.add_argument("--predict", default=None,
                     help="where to write BIRD-format predictions "
                          "(default: alongside the results jsonl as predict.json).")
    args = ap.parse_args()
    # When running the whole provided file (test/dev), don't randomly subsample:
    # default --n to the full input size unless the caller overrides it.
    n = args.n
    if args.input and n == 1534:
        try:
            n = len(json.loads(Path(args.input).read_text()))
        except Exception:
            pass
    asyncio.run(_amain(n, args.seed, args.workers,
                        args.concurrent_questions, db=args.db, limit=args.limit,
                        input_path=args.input, predict_path=args.predict))


if __name__ == "__main__":
    main()
