"""
run_schema_predictor_intrinsic.py — Experiment 2 (intrinsic check) of the
schema-linking follow-up plan: a dedicated schema-predictor agent, taught by
few-shot (train_question, its own schema, its gold-derived "perfect schema")
pairs, then asked to predict the perfect schema for a DEV question against
its OWN full schema - without ever seeing the dev question's gold SQL.

Labels for the few-shot bank are computed FOR FREE (local AST parse of train
gold SQL via the existing extract_oracle_schema() from run_oracle_merger_
pilot.py) - no LLM calls for that part. Retrieval is inherently cross-database
(train and dev/hard databases are disjoint in this repo), satisfying the
"always cross-schema" rule with no extra work.

This script only runs the INTRINSIC check: 1 LLM call per dev question (the
predictor itself), then scores precision/recall/F1 of its predicted tables/
columns against the TRUE oracle schema (extracted from the dev question's own
gold SQL - used only for scoring here, never shown to the predictor). No
merger calls yet - that's the extrinsic follow-up, only worth running if this
looks good.

Usage:
  python3 run_schema_predictor_intrinsic.py --n 100 --seed 5 --k-train 5 \
      --model-alias gpt-5.6-luna --workers 8
"""
from __future__ import annotations

import argparse
import asyncio
import json
import random
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
for p in ("generation", "judge", "data_bird"):
    sys.path.insert(0, str(ROOT / p))
sys.path.insert(0, str(HERE))

from schema_utils import iter_all_schemas, render_schema, render_foreign_keys  # noqa: E402
from llm_call import AsyncCaller, gather_with_progress                       # noqa: E402
from retrieval import Retriever                                              # noqa: E402
from run_oracle_merger_pilot import extract_oracle_schema                    # noqa: E402

DEV_PATH = ROOT / "data" / "bird" / "dev" / "dev.json"
SPECIALISTS_PATH = HERE / "runs" / "4.8" / "phase4_specialists.jsonl"
OUT_PATH = HERE / "runs" / "4.8" / "schema_predictor_intrinsic.jsonl"

PREDICTOR_TASK = """You are a schema-linking assistant for text-to-SQL. You will be shown several \
EXAMPLES from OTHER databases, each giving a question and the exact set of tables/columns needed \
to answer it (including join-key columns, even ones not directly selected). Learn the PATTERN of \
how a question's wording maps to the minimal set of schema elements it needs - not facts about \
those specific databases, which are unrelated to the one you'll actually be asked about.

Then, for the ACTUAL question (against its OWN database schema, shown after the examples), predict \
the minimal set of tables and columns needed to answer it - every table/column actually needed, \
including join-key columns for any required join, but nothing irrelevant.

Think step by step inside <reasoning> tags, then output ONLY a JSON object (no markdown fences):
{"tables": ["table1", "table2"], "columns": ["table1.col_a", "table1.col_b", "table2.col_c"]}"""


def render_exemplar(ex: dict, entry: dict) -> str:
    tables, cols_by_table = extract_oracle_schema(ex["sql"], entry)
    col_list = sorted(f"{t}.{c}" for t, cs in cols_by_table.items() for c in cs)
    hint = f"\nHint: {ex['evidence']}" if ex.get("evidence") else ""
    return (f"Question: {ex['question']}{hint}\n"
            f"Perfect schema: tables={sorted(tables)}, columns={col_list}")


def build_predictor_messages(d: dict, entry: dict, db_dir, exemplars: list, schemas: dict):
    ex_blocks = []
    for ex in exemplars:
        ex_entry, _ = schemas[ex["db_id"]]
        ex_blocks.append(render_exemplar(ex, ex_entry))
    examples_block = "\n\n".join(f"--- Example {i+1} ---\n{b}" for i, b in enumerate(ex_blocks))

    schema_str = render_schema(entry, db_dir)
    fk_str = render_foreign_keys(entry)
    system = f"{PREDICTOR_TASK}\n\n{examples_block}"
    hint = f"\nHint: {d.get('evidence', '')}" if d.get("evidence") else ""
    user = (f"--- ACTUAL DATABASE SCHEMA ---\n\n{schema_str}\n\n--- FOREIGN KEYS ---\n\n{fk_str}\n\n"
            f"--- ACTUAL QUESTION ---\n\nQuestion: {d['question']}{hint}")
    return system, user


def parse_prediction(raw: str) -> dict:
    text = raw
    if "</reasoning>" in text:
        text = text.split("</reasoning>", 1)[1].strip()
    text = re.sub(r"^```json\s*", "", text.strip())
    text = re.sub(r"\s*```$", "", text)
    try:
        p = json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r'\{[^{}]*"tables"[^{}]*\}', text, re.DOTALL)
        p = json.loads(m.group()) if m else {}
    tables = [t.lower() for t in p.get("tables", []) if isinstance(t, str)]
    cols = []
    for c in p.get("columns", []):
        if isinstance(c, str) and "." in c:
            t, col = c.split(".", 1)
            cols.append((t.lower(), col.lower()))
    return {"tables": set(tables), "columns": set(cols)}


def prf1(pred: set, true: set):
    if not pred and not true:
        return 1.0, 1.0, 1.0
    if not pred:
        return 0.0, 0.0, 0.0
    if not true:
        return 0.0, 0.0, 0.0
    tp = len(pred & true)
    precision = tp / len(pred)
    recall = tp / len(true)
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
    return precision, recall, f1


async def _amain(n: int, seed: int, k_train: int, model_alias: str, workers: int):
    dev = json.loads(DEV_PATH.read_text())
    random.seed(seed)
    sample = random.sample(dev, n)

    schemas = {db: (e, dd) for db, e, dd in iter_all_schemas()}
    retriever = Retriever()
    caller = AsyncCaller(model_alias=model_alias, max_concurrency=workers, max_tokens=1200)

    async def _predict(d: dict):
        entry, db_dir = schemas[d["db_id"]]
        q_emb = retriever.embedder.encode([d["question"]], convert_to_tensor=True,
                                           normalize_embeddings=True)[0]
        exemplars = retriever.train_pool.top_k(q_emb, k_train, exclude_exact=d["question"])
        system, user = build_predictor_messages(d, entry, db_dir, exemplars, schemas)
        raw = await caller([{"role": "system", "content": system},
                             {"role": "user", "content": user}])
        pred = parse_prediction(raw)

        true_tables, true_cols_by_table = extract_oracle_schema(d["SQL"], entry)
        true_cols = {(t, c) for t, cs in true_cols_by_table.items() for c in cs}

        t_p, t_r, t_f1 = prf1(pred["tables"], true_tables)
        c_p, c_r, c_f1 = prf1(pred["columns"], true_cols)
        return {
            "question_id": d["question_id"], "db_id": d["db_id"], "difficulty": d.get("difficulty"),
            "pred_tables": sorted(pred["tables"]), "true_tables": sorted(true_tables),
            "pred_columns": sorted(f"{t}.{c}" for t, c in pred["columns"]),
            "true_columns": sorted(f"{t}.{c}" for t, c in true_cols),
            "table_precision": t_p, "table_recall": t_r, "table_f1": t_f1,
            "col_precision": c_p, "col_recall": c_r, "col_f1": c_f1,
        }

    print(f"[predict] running schema predictor for {n} sampled dev questions "
          f"({k_train} cross-db train exemplars each, 1 LLM call/question)...")
    results = await gather_with_progress([_predict(d) for d in sample], desc="schema-predict")

    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with OUT_PATH.open("w") as f:
        for r in results:
            f.write(json.dumps(r) + "\n")

    def avg(key):
        return sum(r[key] for r in results) / len(results)

    print(f"\n=== Schema predictor intrinsic eval (N={n}, seed={seed}, k_train={k_train}) ===")
    print(f"  TABLE   precision={avg('table_precision'):.1%}  recall={avg('table_recall'):.1%}  "
          f"F1={avg('table_f1'):.1%}")
    print(f"  COLUMN  precision={avg('col_precision'):.1%}  recall={avg('col_recall'):.1%}  "
          f"F1={avg('col_f1'):.1%}")

    exact_table_match = sum(1 for r in results if set(r["pred_tables"]) == set(r["true_tables"]))
    print(f"  exact table-set match: {exact_table_match}/{n} ({exact_table_match/n:.1%})")
    print(f"\nwrote {OUT_PATH}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=100)
    ap.add_argument("--seed", type=int, default=5)
    ap.add_argument("--k-train", type=int, default=5)
    ap.add_argument("--model-alias", default="gpt-5.6-luna")
    ap.add_argument("--workers", type=int, default=8)
    args = ap.parse_args()
    asyncio.run(_amain(args.n, args.seed, args.k_train, args.model_alias, args.workers))


if __name__ == "__main__":
    main()
