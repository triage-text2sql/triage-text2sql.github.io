"""
execution.py — Shared local SQLite execution harness for scoring generated
SQL against gold: EX (execution accuracy) and VES (Valid Efficiency Score),
both implementing the official BIRD algorithms verbatim (see
generation/reference/bird_evaluator_verbatim.py and
bird_evaluation_ves_verbatim.py - the actual files fetched from
https://github.com/AlibabaResearch/DAMO-ConvAI/blob/main/bird/). Pure local
execution - no LLM/API calls anywhere in this module.

EX: results_match() - set(gold_rows) == set(pred_rows). Note this ignores
duplicate rows (a set comparison, not a multiset one) - see that function's
docstring.
VES: score_with_ves() - per-query sqrt(time_ratio)*100, time_ratio from
iterate_num timed repetitions of each query with outlier removal; final VES
is the mean of this contribution across all questions (computed by the
caller, e.g. generation/recompute_ex_ves.py, not this module). VES is
already on a ~0-100 scale (can exceed 100 if predictions run faster than
gold on average) - do NOT format it as a fraction/percent.

Used by:
  - judge/eval_proxy_hard_bank.py           (Phase 2 execution-diff step)
  - generation/run_phase1_baseline.py       (zero-shot / gold-few-shot scoring)
  - generation/run_phase3_fewshot_ladder.py (skeleton / proxy / contrastive scoring)
  - generation/run_phase4_specialists.py    (specialist-pipeline scoring)
"""

from __future__ import annotations

import math
import os
import sqlite3
import time
from pathlib import Path

DATA_BIRD = Path(__file__).resolve().parent.parent / "data" / "bird"
TRAIN_DB_DIR = DATA_BIRD / "train" / "train_databases"
# Directory holding the target databases as <db_id>/<db_id>.sqlite. Override with
# BIRD_DB_DIR to point at the test databases (default: the bundled dev tree).
DEV_DB_DIR = (Path(os.environ["BIRD_DB_DIR"]) if os.environ.get("BIRD_DB_DIR")
              else DATA_BIRD / "dev" / "dev_databases")

TIMEOUT_SECONDS = 30    # matches the official BIRD evaluator's func_timeout(30.0, ...)
                        # (generation/reference/bird_evaluator_verbatim.py)
_PROGRESS_STEPS = 1000  # how often (in SQLite VM instructions) the timeout is checked
VES_REPS = 3            # official default is 100 (see score_with_ves) - lowered here
                        # for practicality; pass iterate_num=100 for a faithful final report


def db_path_for(db_id: str, split: str = "dev") -> Path:
    """split: 'dev' or 'train' - which *_databases/ tree to resolve db_id in."""
    root = DEV_DB_DIR if split == "dev" else TRAIN_DB_DIR
    return root / db_id / f"{db_id}.sqlite"


_OPEN_RETRIES = 3
_OPEN_RETRY_DELAY = 0.3  # seconds


def _run_query_once(db_path: Path, sql: str, timeout: int
                     ) -> tuple[bool, "list | None", str]:
    start = time.monotonic()
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    conn.set_progress_handler(
        lambda: 1 if (time.monotonic() - start) > timeout else 0, _PROGRESS_STEPS)
    try:
        cur = conn.cursor()
        cur.execute(sql)
        rows = cur.fetchall()
        return True, rows, ""
    except sqlite3.OperationalError as e:
        if "interrupted" in str(e).lower():
            return False, None, f"timeout after {timeout}s"
        return False, None, f"{type(e).__name__}: {e}"
    except Exception as e:
        return False, None, f"{type(e).__name__}: {e}"
    finally:
        conn.close()


def run_query(db_path: Path, sql: str, timeout: int = TIMEOUT_SECONDS
              ) -> tuple[bool, "list | None", str]:
    """Executes sql read-only against db_path. Returns (ok, rows_or_None,
    error_message) - rows are returned as fetchall() gives them; ordering is
    irrelevant since results_match() compares them as sets (see there).

    Timeout uses sqlite3's progress handler (checked every _PROGRESS_STEPS VM
    instructions, well inside a single execute()/fetchall() call) rather than
    signal.alarm - a signal only gets delivered when control returns to the
    Python interpreter, so it can sit queued indefinitely while a single
    long-running C-level sqlite3_step() call is in progress (observed: a
    runaway cross-join query ran 15+ minutes past its "15s" alarm timeout).
    The progress handler is invoked by SQLite itself mid-query and can abort
    it immediately by returning non-zero.

    Retries _OPEN_RETRIES times on "unable to open database file" - observed
    to fail deterministically for one large (261MB) database across an
    entire batch, then succeed reliably on manual retry seconds later; looks
    like a transient OS/filesystem hiccup (e.g. Gatekeeper/Spotlight
    scanning a large file on first substantial access) rather than a logic
    bug, so a short retry is cheap insurance against silently zeroing out an
    entire database's worth of rows."""
    last = (False, None, "")
    for attempt in range(_OPEN_RETRIES):
        last = _run_query_once(db_path, sql, timeout)
        if last[0] or "unable to open database file" not in last[2]:
            return last
        time.sleep(_OPEN_RETRY_DELAY)
    return last


def results_match(gold_rows: "list | None", pred_rows: "list | None") -> bool:
    """Official BIRD execution-accuracy comparison, verbatim from
    generation/reference/bird_evaluator_verbatim.py's compute_execution_accuracy():
    `set(result['results']) == set(predict_results[i]['results'])` - a SET
    comparison, not a multiset/list one. Row order never mattered, but
    critically: DUPLICATE ROWS ARE IGNORED. gold=[(1,),(1,),(2,)] and
    pred=[(1,),(2,)] compare EQUAL under this metric (both are {(1,),(2,)}
    as sets), even though a multiset comparison would call them different.
    This is stricter-than-it-sounds in one direction (still requires the
    same distinct rows) but more lenient than a naive list/multiset compare
    whenever duplicate rows are involved - e.g. a spurious extra JOIN that
    only duplicates existing rows doesn't cost a match under this metric,
    though an incorrect/missing DISTINCT that changes which distinct values
    appear still would."""
    if gold_rows is None or pred_rows is None:
        return False
    return set(gold_rows) == set(pred_rows)


def score(db_id: str, gold_sql: str, pred_sql: str, split: str = "dev"
          ) -> dict:
    """Convenience wrapper: executes both queries against the same DB, returns
    a result dict with both executions' status plus the match verdict."""
    db_path = db_path_for(db_id, split)
    gold_ok, gold_rows, gold_err = run_query(db_path, gold_sql)
    pred_ok, pred_rows, pred_err = run_query(db_path, pred_sql)
    return {
        "gold_exec_ok": gold_ok, "gold_exec_err": gold_err,
        "pred_exec_ok": pred_ok, "pred_exec_err": pred_err,
        "match": results_match(gold_rows, pred_rows),
    }


def _clean_abnormal(values: list[float]) -> list[float]:
    """Verbatim from generation/reference/bird_evaluation_ves_verbatim.py's
    clean_abnormal(): drop values outside mean +/- 3*std."""
    import numpy as np
    arr = np.asarray(values)
    mean, std = arr.mean(), arr.std()
    return [v for v in values if mean - 3 * std < v < mean + 3 * std]


def _timed_single_execute(db_path: Path, sql: str, timeout: int) -> "float | None":
    """Times ONE execution of sql - matches the official execute_sql(): a
    fresh connection per call, and times ONLY cursor.execute(), not
    fetchall() (the official script's own choice, reproduced verbatim even
    though it means the timing excludes row materialization). Returns None
    on any failure/timeout - a safety net the official script doesn't have
    per-call (it only wraps the whole iterated measurement in one long
    func_timeout); this is TIMEOUT_SECONDS-guarded per call instead, via the
    same sqlite3 progress-handler mechanism as run_query()."""
    start = time.monotonic()
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    conn.set_progress_handler(
        lambda: 1 if (time.monotonic() - start) > timeout else 0, _PROGRESS_STEPS)
    try:
        t0 = time.perf_counter()
        conn.cursor().execute(sql)
        return time.perf_counter() - t0
    except Exception:
        return None
    finally:
        conn.close()


def score_with_ves(db_id: str, gold_sql: str, pred_sql: str, split: str = "dev",
                    iterate_num: int = VES_REPS, timeout: int = TIMEOUT_SECONDS) -> dict:
    """Official BIRD Valid Efficiency Score, verbatim algorithm from
    generation/reference/bird_evaluation_ves_verbatim.py
    (bird/llm/src/evaluation_ves.py's iterated_execute_sql + compute_ves):

      1. One correctness-check execution (with fetchall) of both queries;
         results_match() decides match/no-match (official, set-based - see
         that function's docstring). No match -> ves contribution is 0,
         skip all timing.
      2. Otherwise, time `iterate_num` repetitions of EACH query SEPARATELY
         (fresh connection every single call, matching official
         execute_sql()), collecting one ratio = gold_time / pred_time per
         repetition.
      3. Drop outliers beyond mean +/- 3*std across those ratios
         (clean_abnormal()).
      4. time_ratio = mean of what's left.
      5. This query's contribution to the final VES score is
         sqrt(time_ratio) * 100 (0 for a non-match). The final reported VES
         is the mean of this contribution across all questions
         (bird_evaluation_ves_verbatim.py's compute_ves():
         `sum(sqrt(time_ratio)*100) / num_queries`) - done by the caller
         (generation/recompute_ex_ves.py), not here.

    iterate_num defaults lower than the official script's default of 100
    (see VES_REPS) purely for practicality during iteration - pass
    iterate_num=100 for a fully faithful final report; the ALGORITHM above
    is unchanged either way, only the rep count."""
    db_path = db_path_for(db_id, split)
    gold_ok, gold_rows, gold_err = run_query(db_path, gold_sql, timeout)
    pred_ok, pred_rows, pred_err = run_query(db_path, pred_sql, timeout)
    match = results_match(gold_rows, pred_rows) if (gold_ok and pred_ok) else False

    ves_contribution = 0.0
    if match:
        ratios = []
        for _ in range(iterate_num):
            pred_time = _timed_single_execute(db_path, pred_sql, timeout)
            gold_time = _timed_single_execute(db_path, gold_sql, timeout)
            if pred_time is None or gold_time is None or pred_time <= 0:
                continue
            ratios.append(gold_time / pred_time)
        cleaned = _clean_abnormal(ratios) if ratios else []
        time_ratio = (sum(cleaned) / len(cleaned)) if cleaned else 0.0
        ves_contribution = math.sqrt(time_ratio) * 100

    return {
        "gold_exec_ok": gold_ok, "gold_exec_err": gold_err or "",
        "pred_exec_ok": pred_ok, "pred_exec_err": pred_err or "",
        "match": match, "ves": ves_contribution,
    }
