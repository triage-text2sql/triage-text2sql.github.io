"""
run_oracle_merger_pilot.py — Perfect-schema-linking ablation on the MERGER
step only (the 6 specialist candidates are unchanged, reused as-is from the
already-stored skill/runs/4.8/phase4_specialists.jsonl - 0 new calls for
those). Isolates: given the SAME 6 candidate SQLs + their SAME SQLite
execution-result feedback, does giving the exec-feedback merger the MINIMAL
schema needed to execute gold SQL - only referenced tables, only referenced
columns, plus any PK/FK columns needed for joins even if not explicitly
selected - instead of the full per-db schema (with all tables/columns/
descriptions/value profiles), change its EX?

Two merges per sampled question, paired on identical inputs otherwise:
  baseline_sql — merger sees the FULL per-db schema (today's config,
                 skill/exec_feedback_pilot.py's EXEC_MERGER_TASK): every
                 table, every column, CSV-derived descriptions, hop-paths.
  oracle_sql   — merger sees ONLY: tables referenced anywhere in gold SQL
                 (FROM/JOIN/subqueries/CTEs), columns referenced anywhere in
                 gold SQL (SELECT/WHERE/GROUP BY/ORDER BY/HAVING/JOIN...ON),
                 plus PK/FK columns needed for joins between two oracle
                 tables even if not otherwise referenced. No column
                 descriptions, no value profiles, no other metadata - just
                 table/column/type/[PK] structure, the minimum needed to
                 execute gold SQL.
Same candidates, same execution-result previews, same contrastive few-shot
exemplars in both calls - only the schema block differs. 2 new LLM calls per
question total (1 baseline + 1 oracle); specialists are 100% reused.

Usage:
  python3 run_oracle_merger_pilot.py --n 100 --seed 2 --model 4.8 \
      --model-alias gpt-5.6-luna --workers 8
"""
from __future__ import annotations

import argparse
import asyncio
import json
import random
import sys
from collections import Counter, defaultdict
from pathlib import Path

import sqlglot
from sqlglot import exp

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
for p in ("generation", "judge", "data_bird"):
    sys.path.insert(0, str(ROOT / p))
sys.path.insert(0, str(HERE))

from generator_prompt import clean_sql                                       # noqa: E402
from schema_utils import iter_all_schemas, render_schema, render_foreign_keys  # noqa: E402
from llm_call import AsyncCaller, gather_with_progress                       # noqa: E402
from retrieval import Retriever                                              # noqa: E402
from selector_tier1 import _connect, result_signature                        # noqa: E402
from run_phase4_specialists import build_contrastive_block, CONTRASTIVE_PROXY_BANK_PATH  # noqa: E402
from exec_feedback_pilot import EXEC_MERGER_TASK, build_merger_msg, _preview  # noqa: E402

DEV_PATH = ROOT / "data" / "bird" / "dev" / "dev.json"
SPECIALISTS_PATH = HERE / "runs" / "4.8" / "phase4_specialists.jsonl"
OUT_PATH = HERE / "runs" / "4.8" / "oracle_merger_pilot.jsonl"


# ── Oracle table+column extraction (gold SQL -> exact tables/columns used) ──
def extract_oracle_schema(sql: str, entry: dict) -> "tuple[set, dict]":
    """Returns (oracle_table_names_lower, {table_lower: {col_lower, ...}}) -
    every table gold SQL references (FROM/JOIN/subqueries/CTEs) and, per
    table, every column gold SQL references anywhere (SELECT/WHERE/GROUP BY/
    ORDER BY/HAVING/JOIN...ON - sqlglot's Column pass covers the whole tree,
    not just the SELECT list), plus a PK/FK safety net (see below)."""
    try:
        tree = sqlglot.parse_one(sql, read="sqlite")
    except Exception:
        return set(), {}

    alias_to_table = {}
    oracle_tables = set()
    for t in tree.find_all(exp.Table):
        if not t.name:
            continue
        real = t.name.lower()
        oracle_tables.add(real)
        alias_to_table[real] = real
        if t.alias:
            alias_to_table[t.alias.lower()] = real

    tables_orig = entry["table_names_original"]
    real_cols_by_table = defaultdict(set)      # table_lower -> {col_lower,...} (actual schema)
    for t_idx, col_name in entry["column_names_original"]:
        if t_idx == -1:
            continue
        real_cols_by_table[tables_orig[t_idx].lower()].add(col_name.lower())

    cols_by_table = defaultdict(set)
    unqualified = set()
    for c in tree.find_all(exp.Column):
        name = c.name.lower() if c.name else ""
        if not name:
            continue
        tbl_ref = c.table.lower() if c.table else None
        if tbl_ref and tbl_ref in alias_to_table:
            cols_by_table[alias_to_table[tbl_ref]].add(name)
        else:
            unqualified.add(name)              # e.g. single-table query, no prefix

    # Unqualified column refs: assign to every oracle table that actually has
    # a same-named column (unambiguous for single-table queries; safe
    # over-inclusion - never omission - when a name happens to collide).
    for name in unqualified:
        for tbl in oracle_tables:
            if name in real_cols_by_table.get(tbl, set()):
                cols_by_table[tbl].add(name)

    # PK/FK safety net: for any declared FK between two oracle tables, keep
    # both endpoint columns even if sqlglot's column pass missed them (e.g.
    # USING(...) joins) - "PK/FK columns needed for joins" per spec.
    for col_a, col_b in entry.get("foreign_keys", []):
        ta_idx, na = entry["column_names_original"][col_a]
        tb_idx, nb = entry["column_names_original"][col_b]
        ta_name, tb_name = tables_orig[ta_idx].lower(), tables_orig[tb_idx].lower()
        if ta_name in oracle_tables and tb_name in oracle_tables:
            cols_by_table[ta_name].add(na.lower())
            cols_by_table[tb_name].add(nb.lower())

    return oracle_tables, cols_by_table


# ── Filter a schema_utils entry dict down to oracle tables AND columns ─────
def filter_entry_to_oracle(entry: dict, oracle_tables_lower: set,
                            cols_by_table_lower: dict) -> "dict | None":
    tables = entry["table_names_original"]
    keep_t_idx = [i for i, t in enumerate(tables) if t.lower() in oracle_tables_lower]
    if not keep_t_idx:
        return None                     # extraction found nothing usable -> caller falls back
    idx_map = {old: new for new, old in enumerate(keep_t_idx)}
    new_tables = [tables[i] for i in keep_t_idx]

    cols = entry["column_names_original"]
    types = entry["column_types"]
    pk_flat = set()
    for pk in entry.get("primary_keys", []):
        pk_flat.update(pk if isinstance(pk, list) else [pk])

    new_cols, new_types, old_to_new_col = [], [], {}
    for old_ci, (t_idx, col_name) in enumerate(cols):
        if t_idx == -1:
            continue                    # drop the wildcard "*" pseudo-column entirely
        if t_idx not in idx_map:
            continue
        table_lower = tables[t_idx].lower()
        if col_name.lower() not in cols_by_table_lower.get(table_lower, set()):
            continue                    # not referenced by gold SQL -> drop
        old_to_new_col[old_ci] = len(new_cols)
        new_cols.append([idx_map[t_idx], col_name])
        new_types.append(types[old_ci] if old_ci < len(types) else "unknown")

    new_pk = [old_to_new_col[i] for i in pk_flat if i in old_to_new_col]
    new_fks = [[old_to_new_col[a], old_to_new_col[b]]
               for a, b in entry.get("foreign_keys", [])
               if a in old_to_new_col and b in old_to_new_col]

    return {"db_id": entry["db_id"], "table_names_original": new_tables,
            "column_names_original": new_cols, "column_types": new_types,
            "primary_keys": new_pk, "foreign_keys": new_fks}


# ── Lean renderer: table/column/type/[PK] ONLY - no descriptions, no value
# profiles, no other metadata (unlike schema_utils.render_schema) ──────────
def render_oracle_schema(filtered_entry: dict) -> str:
    tables = filtered_entry["table_names_original"]
    cols = filtered_entry["column_names_original"]
    types = filtered_entry["column_types"]
    pk_flat = set()
    for pk in filtered_entry.get("primary_keys", []):
        pk_flat.update(pk if isinstance(pk, list) else [pk])
    by_table = {i: [] for i in range(len(tables))}
    for col_idx, (t_idx, col_name) in enumerate(cols):
        by_table[t_idx].append((col_idx, col_name))
    parts = []
    for t_idx, table in enumerate(tables):
        lines = [f"TABLE {table}"]
        for col_idx, col_name in by_table[t_idx]:
            col_type = types[col_idx] if col_idx < len(types) else "unknown"
            marker = " [PK]" if col_idx in pk_flat else ""
            lines.append(f"  - {col_name} ({col_type}){marker}")
        parts.append("\n".join(lines))
    return "\n\n".join(parts)


# ── Merger system prompt for the oracle condition (own hop-path handling) ──
def build_oracle_merger_system_prompt(db_id: str, filtered_entry: dict,
                                       merger_task: str) -> str:
    schema_str = render_oracle_schema(filtered_entry)
    fk_str = render_foreign_keys(filtered_entry)
    hop_note = ("(schema restricted to the exact tables/columns gold SQL "
                "uses - any join you need is one of the FOREIGN KEYS above)")
    return f"""You are an expert SQLite SQL merger for the database "{db_id}".

--- DATABASE SCHEMA -----------------------------------------------------------

{schema_str}

--- FOREIGN KEYS --------------------------------------------------------------

{fk_str}

--- JOIN GRAPH / MULTI-HOP PATHS ----------------------------------------------

{hop_note}

--- YOUR TASK ---------------------------------------------------------------

{merger_task}"""


# Mirrors generator_prompt.build_merger_system_prompt exactly, for the
# full-schema baseline call (same template, reused here to keep both system
# prompts textually identical apart from the schema/FK/hop-path body).
def build_full_merger_system_prompt(db_id: str, entry: dict, db_dir: "Path | None",
                                     merger_task: str, schema_graphs: dict) -> str:
    from generator_prompt import render_hop_paths  # noqa: E402  (re-export from schema_utils)
    schema_str = render_schema(entry, db_dir)
    fk_str = render_foreign_keys(entry)
    hop_str = render_hop_paths(db_id, schema_graphs)
    return f"""You are an expert SQLite SQL merger for the database "{db_id}".

--- DATABASE SCHEMA -----------------------------------------------------------

{schema_str}

--- FOREIGN KEYS --------------------------------------------------------------

{fk_str}

--- JOIN GRAPH / MULTI-HOP PATHS ----------------------------------------------

{hop_str}

--- YOUR TASK ---------------------------------------------------------------

{merger_task}"""


def score_against_gold(db_id: str, gold_sql: str, sql: str) -> bool:
    con = _connect(db_id)
    try:
        gold = result_signature(con, gold_sql)
        got = result_signature(con, sql)
        if gold is None or got is None:
            return False
        return got == gold
    finally:
        con.close()


async def _amain(n: int, seed: int, model_dir: str, model_alias: str, workers: int):
    dev = {r["question_id"]: r for r in json.loads(DEV_PATH.read_text())}
    recs = [json.loads(l) for l in SPECIALISTS_PATH.read_text().splitlines() if l.strip()]

    random.seed(seed)
    sample = random.sample(recs, n)

    schemas = {db: (e, dd) for db, e, dd in iter_all_schemas()}
    from schema_utils import load_schema_graphs
    schema_graphs = load_schema_graphs()
    retriever = Retriever()
    contrastive = json.loads(CONTRASTIVE_PROXY_BANK_PATH.read_text())
    caller = AsyncCaller(model_alias=model_alias, max_concurrency=workers, max_tokens=1500)

    fallback_count = 0
    table_stats = []   # (n_oracle_tables, n_total_tables, n_oracle_cols, n_total_cols) per question

    async def _both_merges(rec: dict):
        nonlocal fallback_count
        d = dev[rec["question_id"]]
        db_id = rec["db_id"]
        entry, db_dir = schemas[db_id]
        gold_sql = d["SQL"]

        con = _connect(db_id)
        try:
            cand_prev = []
            for c in rec["candidates"]:
                status, _ = _preview(con, c["sql"])
                cand_prev.append({"id": c["id"], "sql": c["sql"],
                                   "reasoning": (c.get("reasoning") or "")[:400],
                                   "result": status})
        finally:
            con.close()

        hard_ex = retriever.retrieve_hard_same_db(d["question"], db_id, k=5)
        examples = build_contrastive_block(hard_ex, contrastive)
        merger_rec = {"question": d["question"], "evidence": d.get("evidence", ""),
                       "candidates": cand_prev}
        user_msg = build_merger_msg(merger_rec, examples)

        # -- baseline: full schema --
        sysp_full = build_full_merger_system_prompt(db_id, entry, db_dir,
                                                      EXEC_MERGER_TASK, schema_graphs)
        raw_base = await caller([{"role": "system", "content": sysp_full},
                                  {"role": "user", "content": user_msg}])
        baseline_sql = clean_sql(raw_base)

        # -- oracle: table+column-restricted schema (only what gold SQL needs) --
        oracle_tables, cols_by_table = extract_oracle_schema(gold_sql, entry)
        filtered_entry = filter_entry_to_oracle(entry, oracle_tables, cols_by_table)
        n_total_tables = len(entry["table_names_original"])
        n_total_cols = len(entry["column_names_original"])
        if filtered_entry is None:
            fallback_count += 1
            filtered_entry = entry           # extraction failed -> fall back to full schema
            n_oracle_tables, n_oracle_cols = n_total_tables, n_total_cols
        else:
            n_oracle_tables = len(filtered_entry["table_names_original"])
            n_oracle_cols = len(filtered_entry["column_names_original"])
        table_stats.append((n_oracle_tables, n_total_tables, n_oracle_cols, n_total_cols))

        sysp_oracle = build_oracle_merger_system_prompt(db_id, filtered_entry, EXEC_MERGER_TASK)
        raw_oracle = await caller([{"role": "system", "content": sysp_oracle},
                                    {"role": "user", "content": user_msg}])
        oracle_sql = clean_sql(raw_oracle)

        return baseline_sql, oracle_sql

    print(f"[merge] running baseline (full-schema) + oracle (table-restricted-schema) "
          f"merges for {n} sampled questions (2 calls/question, specialists 100% reused)...")
    pairs = await gather_with_progress([_both_merges(r) for r in sample], desc="oracle-merge")

    base_correct = [score_against_gold(r["db_id"], dev[r["question_id"]]["SQL"], b)
                    for r, (b, o) in zip(sample, pairs)]
    oracle_correct = [score_against_gold(r["db_id"], dev[r["question_id"]]["SQL"], o)
                      for r, (b, o) in zip(sample, pairs)]

    rows = []
    for r, (b, o), bok, ook, (n_ot, n_tt, n_oc, n_tc) in zip(sample, pairs, base_correct,
                                                    oracle_correct, table_stats):
        rows.append({"question_id": r["question_id"], "db_id": r["db_id"],
                     "difficulty": r["difficulty"], "baseline_sql": b,
                     "baseline_correct": bok, "oracle_sql": o,
                     "oracle_correct": ook, "n_oracle_tables": n_ot, "n_total_tables": n_tt,
                     "n_oracle_cols": n_oc, "n_total_cols": n_tc})
    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with OUT_PATH.open("w") as f:
        for row in rows:
            f.write(json.dumps(row) + "\n")

    n_base_ok, n_ora_ok = sum(base_correct), sum(oracle_correct)
    gained = sum(1 for b, o in zip(base_correct, oracle_correct) if not b and o)
    harmed = sum(1 for b, o in zip(base_correct, oracle_correct) if b and not o)
    unchanged_ok = sum(1 for b, o in zip(base_correct, oracle_correct) if b and o)
    unchanged_bad = sum(1 for b, o in zip(base_correct, oracle_correct) if not b and not o)

    by_diff_base = defaultdict(lambda: [0, 0])
    by_diff_ora = defaultdict(lambda: [0, 0])
    for r, bok, ook in zip(sample, base_correct, oracle_correct):
        by_diff_base[r["difficulty"]][0] += int(bok); by_diff_base[r["difficulty"]][1] += 1
        by_diff_ora[r["difficulty"]][0] += int(ook); by_diff_ora[r["difficulty"]][1] += 1

    avg_oracle_tables = sum(t[0] for t in table_stats) / n
    avg_total_tables = sum(t[1] for t in table_stats) / n
    avg_oracle_cols = sum(t[2] for t in table_stats) / n
    avg_total_cols = sum(t[3] for t in table_stats) / n

    print(f"\n=== Oracle-schema merger ablation (N={n}, seed={seed}) ===")
    print(f"  baseline (full schema)   EX: {n_base_ok/n:.1%}  ({n_base_ok}/{n})")
    print(f"  oracle   (table+column-restricted) EX: {n_ora_ok/n:.1%}  ({n_ora_ok}/{n})")
    print(f"  gained (wrong->right): {gained}   harmed (right->wrong): {harmed}")
    print(f"  unchanged correct: {unchanged_ok}   unchanged wrong: {unchanged_bad}")
    print(f"  avg tables shown: oracle {avg_oracle_tables:.1f} vs full {avg_total_tables:.1f}")
    print(f"  avg columns shown: oracle {avg_oracle_cols:.1f} vs full {avg_total_cols:.1f}")
    print(f"  oracle-extraction fallbacks (used full schema instead): {fallback_count}/{n}")
    print(f"\n  by difficulty (baseline -> oracle):")
    for d in sorted(set(by_diff_base) | set(by_diff_ora)):
        bc, bt = by_diff_base[d]
        oc, ot = by_diff_ora[d]
        print(f"    {d:12s} n={bt:3d}  {bc/bt:.1%} -> {oc/ot:.1%}")
    print(f"\nwrote {OUT_PATH}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=100)
    ap.add_argument("--seed", type=int, default=2)
    ap.add_argument("--model", default="4.8")
    ap.add_argument("--model-alias", default="gpt-5.6-luna")
    ap.add_argument("--workers", type=int, default=8)
    args = ap.parse_args()
    asyncio.run(_amain(args.n, args.seed, args.model, args.model_alias, args.workers))


if __name__ == "__main__":
    main()
