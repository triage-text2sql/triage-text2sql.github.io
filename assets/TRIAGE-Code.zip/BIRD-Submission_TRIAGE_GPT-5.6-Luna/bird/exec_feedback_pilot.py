"""
exec_feedback_pilot.py — Pilot of the EXECUTION-FEEDBACK MERGER (Goal A).

Idea: the current merger sees each candidate's reasoning + SQL but NOT what the
SQL returns. Here we show the merger each candidate's ACTUAL executed result
(rows preview or error) and let it pick/synthesize. That result signal is the
discriminator the free selectors lacked (71.6% ceiling vs 75.5% oracle).

Leakage discipline (no labels in the method):
  - Subset is chosen LABEL-FREE: the ~PILOT_N lowest-confidence questions by
    specialist vote margin (how much the 6 agents disagree), never by
    correctness.
  - The merger uses question + schema + hop + few-shot + candidates' SQL +
    candidates' RESULTS. No gold anywhere.
  - Gold is used ONLY to score afterwards (evaluation), for a fixed a-priori
    design, one read-out. No prompt tuning against the dev number.

Phases: (1) local, no-LLM staging picks the subset + gathers result previews;
(2) 1 LLM call/question (gpt-5.6-luna) for the exec-feedback merge;
(3) local scoring compares it to the existing merger and to plurality on the
SAME subset.

Usage:  python3 exec_feedback_pilot.py --model 4.8 --pilot-n 150
"""
from __future__ import annotations
import argparse, asyncio, concurrent.futures as cf, json, os, sys, time
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
for p in ("generation", "judge", "data_bird"):
    sys.path.insert(0, str(ROOT / p))
sys.path.insert(0, str(HERE))

from execution import score_with_ves  # noqa: E402
from generator_prompt import build_merger_system_prompt, build_generator_user_message, clean_sql  # noqa: E402
from schema_utils import iter_all_schemas  # noqa: E402
from llm_call import AsyncCaller, gather_with_progress  # noqa: E402
from retrieval import Retriever  # noqa: E402
from selector_tier1 import _connect, result_signature, AGENT_IDS  # noqa: E402
from run_phase4_specialists import build_contrastive_block, CONTRASTIVE_PROXY_BANK_PATH  # noqa: E402

DEV_PATH = ROOT / "data" / "bird" / "dev" / "dev.json"
ROWS_SHOWN = 15
REASON_CHARS = 400

EXEC_MERGER_TASK = """You are given a question and several candidate SQL queries \
produced by specialists. For EACH candidate you are shown its reasoning, its \
SQL, and the ACTUAL RESULT it produced when executed against this database \
(a preview of the returned rows, or the execution error).

Use the results as evidence: a candidate that errors, returns 0 rows when the \
question expects an answer, or returns an implausibly large/degenerate result \
is likely wrong. Judge which candidate's SQL AND result best answer the \
question; you may also synthesize a corrected query.

Think step by step inside <reasoning> tags (compare the candidates' results \
against what the question asks), then output the final query inside <sql> tags \
- the SQL must be the ONLY content inside <sql>...</sql>."""


def _preview(con, sql):
    """(status_string, representative) for the prompt; no gold."""
    sig = result_signature(con, sql)          # frozenset or None (error/timeout/oversized)
    if sig is None:
        return "ERROR or timeout (did not execute)", None
    n = len(sig)
    if n == 0:
        return "OK, 0 rows (empty result)", sig
    rows = list(sig)[:ROWS_SHOWN]
    preview = ", ".join(repr(r) for r in rows)
    more = f" (showing {ROWS_SHOWN} of {n})" if n > ROWS_SHOWN else ""
    return f"OK, {n} row(s){more}: [{preview}]", sig


def _stage_one(args):
    """LABEL-FREE: execute the 6 candidates, compute vote margin + previews."""
    qid, db_id, difficulty, agent = args   # agent: list of (id, sql, reasoning)
    con = _connect(db_id)
    try:
        prev, sig_of = [], {}
        for aid, sql, reasoning in agent:
            status, sig = _preview(con, sql)
            prev.append({"id": aid, "sql": sql, "reasoning": (reasoning or "")[:REASON_CHARS],
                         "result": status})
            sig_of[aid] = sig
    finally:
        con.close()
    # margin among NON-EMPTY, valid specialist result sets
    clusters = Counter()
    rep_sql = {}
    for aid, sql, _ in agent:
        s = sig_of[aid]
        if s is not None and len(s) > 0:
            clusters[s] += 1
            rep_sql.setdefault(s, sql)
    if not clusters:
        conf, plur_sql = -1, None            # degenerate -> most uncertain
    else:
        top = clusters.most_common()
        conf = top[0][1] - (top[1][1] if len(top) > 1 else 0)
        plur_sql = rep_sql[top[0][0]]
    return {"qid": qid, "db_id": db_id, "difficulty": difficulty,
            "conf": conf, "candidates": prev, "plurality_sql": plur_sql}


def _sig(db_id, sql):
    con = _connect(db_id)
    try:
        return result_signature(con, sql)
    finally:
        con.close()


def _score_one_multi(args):
    """Hang-proof official-set-equality scoring of several candidate SQLs for
    one question (fresh timeout-guarded, row-capped connection per query)."""
    db_id, gold_sql, methods = args
    gold = _sig(db_id, gold_sql)
    out = {}
    for name, sql in methods.items():
        if not sql:
            out[name] = 0
            continue
        sig = _sig(db_id, sql)
        out[name] = int(sig is not None and gold is not None and sig == gold)
    return out


def _run_pool(worker, tasks, workers, desc):
    results = {}
    pool = ProcessPoolExecutor(max_workers=workers)
    futs = {pool.submit(worker, t): i for i, t in enumerate(tasks)}
    pending, last = set(futs), time.monotonic()
    from tqdm import tqdm
    with tqdm(total=len(futs), desc=desc, ncols=80) as bar:
        while pending:
            done, pending = cf.wait(pending, timeout=30, return_when=cf.FIRST_COMPLETED)
            if done:
                last = time.monotonic()
                for fut in done:
                    results[futs[fut]] = fut.result(); bar.update(1)
            elif time.monotonic() - last > 120:
                break
    pool.shutdown(wait=False, cancel_futures=True)
    return [results.get(i) for i in range(len(tasks))]


def build_merger_msg(rec, examples_block):
    lines = [f"Question: {rec['question']}"]
    if rec.get("evidence"):
        lines.append(f"Hint: {rec['evidence']}")
    lines.append("")
    for c in rec["candidates"]:
        lines.append(f"[{c['id']}]")
        if c["reasoning"]:
            lines.append(f"Reasoning: {c['reasoning']}")
        lines.append(f"SQL: {c['sql']}")
        lines.append(f"Result: {c['result']}\n")
    body = "\n".join(lines)
    return f"{examples_block}\n\n{body}" if examples_block else body


async def _amain(model_dir, pilot_n, model_alias, workers):
    dev = {r["question_id"]: r for r in json.loads(DEV_PATH.read_text())}
    recs = [json.loads(l) for l in (HERE / "runs" / model_dir /
            "phase4_specialists.jsonl").read_text().splitlines() if l.strip()]

    # ---- phase 1: label-free staging (no LLM) ----
    stage_tasks = []
    for r in recs:
        agent = [(c["id"], c["sql"], c.get("reasoning", "")) for c in r["candidates"]]
        stage_tasks.append((r["question_id"], r["db_id"], r.get("difficulty", "unknown"), agent))
    staged = [s for s in _run_pool(_stage_one, stage_tasks, workers, "stage(no-LLM)") if s]
    staged.sort(key=lambda s: s["conf"])                 # ascending confidence
    subset = staged[:pilot_n]
    existing_merged = {r["question_id"]: r["merged_sql"] for r in recs}
    for s in subset:
        d = dev[s["qid"]]
        s["question"] = d["question"]; s["evidence"] = d.get("evidence", "")
    print(f"[stage] picked {len(subset)} lowest-confidence questions (label-free, by vote margin); "
          f"conf range {subset[0]['conf']}..{subset[-1]['conf']}")

    # ---- phase 2: exec-feedback merge, 1 LLM call/question ----
    schemas = {db: (e, dd) for db, e, dd in iter_all_schemas()}
    retriever = Retriever()
    contrastive = json.loads(CONTRASTIVE_PROXY_BANK_PATH.read_text())
    caller = AsyncCaller(model_alias=model_alias, max_concurrency=workers, max_tokens=1500)

    async def _merge(rec):
        entry, db_dir = schemas[rec["db_id"]]
        hard_ex = retriever.retrieve_hard_same_db(rec["question"], rec["db_id"], k=5)
        examples = build_contrastive_block(hard_ex, contrastive)
        sysp = build_merger_system_prompt(rec["db_id"], entry, db_dir, EXEC_MERGER_TASK)
        raw = await caller([{"role": "system", "content": sysp},
                            {"role": "user", "content": build_merger_msg(rec, examples)}])
        return clean_sql(raw)

    merged = await gather_with_progress([_merge(s) for s in subset], desc="exec-feedback-merge")

    # ---- phase 3: score on the SAME subset (labels used only here) ----
    # Hang-proof + pooled: model-generated merged SQL can be a runaway query, so
    # scoring goes through the row-capped/timeout executor, not score_with_ves.
    score_tasks = [(s["db_id"], dev[s["qid"]]["SQL"],
                    {"exec_feedback": new_sql,
                     "existing_merger": existing_merged[s["qid"]],
                     "plurality": s["plurality_sql"]})
                   for s, new_sql in zip(subset, merged)]
    scored = _run_pool(_score_one_multi, score_tasks, workers, "score(no-LLM)")
    ex = defaultdict(lambda: [0, 0])
    for row in scored:
        if row is None:                      # a hung scoring task -> count as wrong
            for name in ("exec_feedback", "existing_merger", "plurality"):
                ex[name][1] += 1
            continue
        for name, m in row.items():
            ex[name][0] += int(m); ex[name][1] += 1

    print(f"\n=== Execution-feedback merger PILOT ({model_dir}, {model_alias}), "
          f"low-confidence subset N={len(subset)} ===")
    for name in ("plurality", "existing_merger", "exec_feedback"):
        c, t = ex[name]
        print(f"  {name:18s} EX {c/t:.1%}  ({c}/{t})")
    print("\n(all three scored on the SAME label-free-selected subset; "
          "exec_feedback is the new method)")
    sys.stdout.flush()
    os._exit(0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="4.8")
    ap.add_argument("--pilot-n", type=int, default=150)
    ap.add_argument("--model-alias", default="gpt-5.6-luna")
    ap.add_argument("--workers", type=int, default=8)
    args = ap.parse_args()
    asyncio.run(_amain(args.model, args.pilot_n, args.model_alias, args.workers))


if __name__ == "__main__":
    main()
