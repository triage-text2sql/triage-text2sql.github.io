"""
models.py — thin shim so the copied `data.py` can keep doing
`from models import resolve_model` unchanged. Backed by the package-root
model.py (proxy-transport-compatible surface).
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from model import resolve_model, call_model, ALL_MODELS  # noqa: E402,F401
