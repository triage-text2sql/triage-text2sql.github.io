"""
run_phase4_specialists.py — Phase 4 of EXPERIMENT_PLAN_BIRD.md: multi-agent
specialist decomposition. Per eval question: 6 specialists (S1-S6) run IN
PARALLEL, each producing its own full candidate SQL (with reasoning) focused on
one failure mode; the merger (S7) then runs TWICE over the same 6 candidates -
once over all 6, once over only the selector-chosen subset
(explicit_selector.select_skills) - so the merger's input set is ablated with
the candidate set held fixed. Each specialist is conditioned on correct CoT +
schema + hop paths + 5 same-db contrastive-proxy few-shot exemplars (the best
Phase 3 arm). Per question: 6 specialist + 2 merger = 8 LLM calls.

The 6 specialists below are taxonomy-derived (generation/cluster_taxonomy.py,
run on 222 execution-mismatch failures from the 500 highest-join-count train
questions - see generation/taxonomy_clusters.json for the full clustering).
Merged from 10 raw clusters down to 6 non-overlapping categories, covering
100% of the mined failures:
  S1 Aggregation Granularity & DISTINCT Correctness  109/222 (49.1%)
  S2 Literal/Value Matching                            70/222 (31.5%)
  S3 Wrong Column / Join-Path Shortcut                 15/222 ( 6.8%)
  S4 Temporal / Superlative Misinterpretation          13/222 ( 5.9%)
  S5 Missing Required JOIN                              8/222 ( 3.6%)
  S6 Extra/Unnecessary JOIN                             7/222 ( 3.2%)
Aggregation/DISTINCT (S1) and literal matching (S2) dominate (80.6%
combined) - notably NOT join-path errors, contrary to the plan's original
expectation for this schema-diverse benchmark.

Scoring is 100% local execution-accuracy (generation/execution.py) on the
MERGED final SQL - no judge calls anywhere in this script (per-candidate
oracle judging, if wanted, is a Phase 5 training-time concern, not scored
here).

Usage:
  python3 run_phase4_specialists.py
  python3 run_phase4_specialists.py --hard-dbs-only --limit 20   # smoke test
"""

from __future__ import annotations

import argparse
import asyncio
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent / "generation"))
sys.path.insert(0, str(HERE.parent / "judge"))
sys.path.insert(0, str(HERE))

from data import filter_to_hard_dbs, hard_pool_db_ids, load_dev, model_subdir  # noqa: E402
from execution import score  # noqa: E402
from generator_prompt import (  # noqa: E402
    build_generator_system_prompt, build_generator_user_message,
    build_merger_system_prompt, clean_sql,
)
from schema_utils import iter_all_schemas, render_foreign_keys, render_schema  # noqa: E402
from llm_call import AsyncCaller, gather_with_progress  # noqa: E402
from retrieval import Retriever  # noqa: E402
from explicit_selector import select_skills  # noqa: E402

OUT_DIR = HERE / "runs"

# Phase 4 specialists now condition on few-shot exemplars, not schema alone:
# the same 5 same-db, contrastive-proxy exemplars that were the best-performing
# arm in Phase 3 (run_phase3_fewshot_ladder.py, generation/
# contrastive_hard_bank_proxy.json - correct=proxy SQL, incorrect=corrupted
# proxy, fully gold-free). Retrieved once per question and shared by all 6
# specialists (retrieval depends only on question + db_id, not the specialist).
import os as _os
# Contrastive exemplar bank path: overridable via config.yaml -> EXEMPLAR_BANK
# (set by ../run.py); defaults to the packaged BIRD proxy-contrastive bank.
CONTRASTIVE_PROXY_BANK_PATH = (Path(_os.environ["EXEMPLAR_BANK"])
                               if _os.environ.get("EXEMPLAR_BANK")
                               else HERE.parent / "exemplar_bank" / "bird"
                                    / "contrastive_hard_bank_proxy.json")
K_HARD = 5
CONTRASTIVE_HEADER = (
    "--- EXAMPLE QUESTION/SQL PAIRS (5 nearest neighbors from the hard pool, "
    "same database as this question; each shows a correct SQL and, where "
    "available, a similar INCORRECT SQL for the same question - use these to "
    "calibrate) ---")
# Whole-pool variant: exemplars may come from OTHER databases, so each is shown
# with its own schema so the SQL is interpretable.
CONTRASTIVE_HEADER_SCHEMA = (
    "--- EXAMPLE QUESTION/SQL PAIRS (nearest neighbors from the hard pool, drawn "
    "from databases OTHER than the target and GROUPED BY DATABASE: each database's "
    "schema is shown once, followed by its example questions - each with a correct "
    "SQL and a similar INCORRECT SQL. Use these to calibrate) ---")


def _exemplar_schema(db_id: str, schemas: dict) -> str:
    """Compact schema (tables/columns/types + FKs, no long value descriptions)
    for an exemplar's own database, so a cross-database exemplar is readable."""
    entry, _db_dir = schemas[db_id]
    return (f"Schema ({db_id}):\n{render_schema(entry, None)}\n"
            f"Foreign keys:\n{render_foreign_keys(entry)}")


def _pair_text(ex: dict, contrastive_bank: dict) -> str:
    """One contrastive-proxy example: Question / Correct SQL / Incorrect SQL / Why."""
    q = ex["question"]
    pair = contrastive_bank.get(q)
    if pair is None:
        return f"Question: {q}\nCorrect SQL: {ex['sql']}"
    lines = [f"Question: {q}", f"Correct SQL: {pair['correct_sql']}",
             f"Incorrect SQL: {pair['incorrect_sql']}"]
    if pair.get("why_incorrect"):
        lines.append(f"Why incorrect: {pair['why_incorrect']}")
    return "\n".join(lines)


def build_contrastive_block(hard_ex: list[dict], contrastive_bank: dict,
                             schemas: "dict | None" = None,
                             include_schema: bool = False) -> str:
    """Renders the contrastive-proxy few-shot block. When include_schema (and a
    schemas map is given), exemplars are GROUPED BY DATABASE: each distinct
    schema is printed once, followed by all its example pairs (so a repeated
    schema isn't duplicated). Default off -> one block per exemplar, no schema
    (the same-db callers are unchanged)."""
    if include_schema and schemas is not None:
        from collections import OrderedDict
        groups: "OrderedDict[str, list]" = OrderedDict()
        for ex in hard_ex:               # preserve similarity order of first appearance
            groups.setdefault(ex["db_id"], []).append(ex)
        blocks = []
        for db_id, exs in groups.items():
            parts = [_exemplar_schema(db_id, schemas)]
            parts += [_pair_text(ex, contrastive_bank) for ex in exs]
            blocks.append("\n\n".join(parts))
        return f"{CONTRASTIVE_HEADER_SCHEMA}\n\n" + "\n\n".join(blocks)
    blocks = [_pair_text(ex, contrastive_bank) for ex in hard_ex]
    return f"{CONTRASTIVE_HEADER}\n\n" + "\n\n".join(blocks)

# Taxonomy-derived specialist list - see module docstring for the mined
# failure counts each one targets (generation/taxonomy_clusters.json).
SPECIALISTS = [
    ("S1", "Aggregation Granularity & DISTINCT Correctness specialist",
     "Focus ONLY on: choosing the correct level of aggregation (do NOT sum/"
     "count when the question wants individual ranked rows via ORDER BY, "
     "and vice versa), correct use of DISTINCT (do not add or drop it "
     "unless the question requires deduplication), and correct ratio/"
     "percentage formulas - get the numerator and denominator at the "
     "SAME grouping granularity (e.g. COUNT(DISTINCT x) vs COUNT(x) must "
     "match what's actually being counted)."),
    ("S2", "Literal/Value Matching specialist",
     "Focus ONLY on: getting every filter literal's exact case, spelling, "
     "and entity-name form right (e.g. 'TRUE' vs 'true', 'Motorcycles' vs "
     "'motorcycles', the exact stored variant of a name) - check the "
     "schema's column descriptions/value hints for the literal's real "
     "stored form rather than guessing a plausible-looking value."),
    ("S3", "Wrong Column / Join-Path Shortcut specialist",
     "Focus ONLY on: returning the exact column the question asks for "
     "(not a similar-looking one, e.g. name vs code), and using the full "
     "intended join path rather than a shortcut join directly between two "
     "tables when an intermediate table is actually required to get the "
     "right rows."),
    ("S4", "Temporal & Superlative Interpretation specialist",
     "Focus ONLY on: correctly interpreting 'oldest'/'latest'/'earliest'/"
     "'most recent' (check which direction each actually means for the "
     "column in question), getting the exact year/date range in any date "
     "filter, and correctly handling NULL/'current record' semantics "
     "(e.g. EndDate IS NULL meaning 'still active')."),
    ("S5", "Missing-JOIN specialist",
     "Focus ONLY on: making sure every table the question's entities and "
     "conditions require is actually joined in - re-check the question "
     "for any entity/filter that implies a table not yet in your join "
     "chain, and add the missing join rather than silently dropping that "
     "condition."),
    ("S6", "Extra-JOIN specialist",
     "Focus ONLY on: not adding any join or join condition beyond what "
     "the question actually requires - an extra join can silently over-"
     "restrict or duplicate rows. Only join a table if the question's "
     "entities or filters explicitly need it."),
    # Added specialists (S7-S10): distinct error modes not owned by S1-S6.
    ("S7", "Subquery / Nesting Structure specialist",
     "Focus ONLY on: the correct query STRUCTURE - when a JOIN is required "
     "versus a subquery (scalar subquery, IN / EXISTS), correlated vs. "
     "uncorrelated subqueries, and correct nesting of aggregates (e.g. "
     "comparing a row to an aggregate over a set, like 'more than the "
     "average'). Do NOT replace a required JOIN with a scalar subquery of the "
     "wrong cardinality, and do not flatten a needed nested aggregate."),
    ("S8", "NULL & Empty-Result specialist",
     "Focus ONLY on: correct NULL and empty-result handling - IS NULL / IS "
     "NOT NULL semantics, that COUNT(col) ignores NULLs while COUNT(*) does "
     "not, distinguishing an empty result from a zero/blank value, and "
     "'current/active record' semantics (e.g. EndDate IS NULL meaning still "
     "active). Add the right NULL filters the question implies (e.g. "
     "'without', 'missing', 'unknown')."),
    ("S9", "String / LIKE Pattern-Matching specialist",
     "Focus ONLY on: string and pattern matching - choosing LIKE with "
     "wildcards vs. an exact '=' comparison, correct wildcard placement "
     "(prefix/suffix/substring for 'starts with' / 'ends with' / 'contains'), "
     "case sensitivity, and whitespace/trimming. Use LIKE '%...%' when the "
     "question implies a partial or substring match rather than an exact one."),
    ("S10", "Ordering / Ranking & Ties specialist",
     "Focus ONLY on: correct ordering and top-k logic - the right ORDER BY "
     "column(s) and direction, LIMIT for 'top/bottom N', and tie handling "
     "(return all tied rows when the question implies it, else a single row). "
     "Do not confuse an aggregate ranking (GROUP BY ... ORDER BY agg) with a "
     "per-row ranking."),
]

MERGER_INSTRUCTIONS = """You will be given a natural-language question and {n} \
candidate solutions, each produced by a specialist focused on one narrow \
concern. Each candidate includes the specialist's step-by-step REASONING and \
its final SQL. Some candidates may be identical; some may be wrong. Weigh the \
reasoning against the schema and the question, then pick the single best \
candidate or synthesize a new query combining their strengths.

Think step by step inside <reasoning> tags (which specialist's reasoning is \
sound, where a candidate went wrong, what the merged query should be), then \
output the final query inside <sql> tags - the SQL must be the ONLY content \
inside <sql>...</sql> (no markdown fences, no leading "SQL:" label).

<reasoning>
...
</reasoning>
<sql>
...
</sql>"""


def extract_reasoning(raw: str) -> str:
    """Pull the specialist's <reasoning>...</reasoning> chain out of its raw
    reply so the merger can see the full trace, not just the final SQL."""
    m = re.search(r"<reasoning>(.*?)</reasoning>", raw, re.DOTALL | re.IGNORECASE)
    return m.group(1).strip() if m else ""


def _schema_lookup() -> dict[str, tuple[dict, "Path | None"]]:
    return {db_id: (entry, db_dir) for db_id, entry, db_dir in iter_all_schemas()}


def build_merger_user_message(question: str, evidence: str, candidates: list[dict],
                               examples_block: str = "") -> str:
    lines = [f"Question: {question}"]
    if evidence:
        lines.append(f"Hint: {evidence}")
    lines.append("")
    for c in candidates:
        lines.append(f"[{c['id']} - {c['name']}]")
        if c.get("reasoning"):
            lines.append(f"Reasoning: {c['reasoning']}")
        lines.append(f"SQL: {c['sql']}\n")
    body = "\n".join(lines)
    # Same same-db contrastive-proxy few-shot block the specialists saw,
    # prepended so the merger has the identical exemplar grounding.
    if examples_block:
        return f"{examples_block}\n\n{body}"
    return body


async def run_specialists(row: dict, entry, db_dir, caller: AsyncCaller,
                           skill_ids: "list[str] | None" = None,
                           examples_block: str = "") -> list[dict]:
    """Stage 1: the given specialists (default: all 6) in parallel.
    skill_ids, if given, restricts to that subset - used by
    run_phase4_with_selector.py's explicit selector to skip irrelevant
    specialists instead of always running all 6.
    examples_block, if given, is the shared same-db contrastive-proxy few-shot
    block (build_contrastive_block); every specialist sees the same exemplars."""
    chosen = SPECIALISTS if skill_ids is None else [
        s for s in SPECIALISTS if s[0] in skill_ids]

    async def _one(spec_id: str, name: str, focus: str) -> dict:
        system_prompt = build_generator_system_prompt(row["db_id"], entry, db_dir, focus)
        user_msg = build_generator_user_message(row["question"], row.get("evidence", ""),
                                                 examples_block)
        raw = await caller([{"role": "system", "content": system_prompt},
                             {"role": "user", "content": user_msg}])
        return {"id": spec_id, "name": name, "sql": clean_sql(raw),
                "reasoning": extract_reasoning(raw), "raw": raw}

    return await asyncio.gather(*[_one(sid, name, focus) for sid, name, focus in chosen])


async def run_merger(row: dict, candidates: list[dict], caller: AsyncCaller,
                      entry: dict, db_dir, examples_block: str = "") -> dict:
    """Stage 2: merger, AFTER stage 1 has fully returned. The merger gets the
    SAME full grounding as the specialists - schema, foreign keys, hop paths
    (build_merger_system_prompt) and the same contrastive-proxy few-shot block
    (examples_block) - plus every candidate's reasoning+SQL. Returns the full
    merger trace (final SQL + its reasoning + raw reply)."""
    system_prompt = build_merger_system_prompt(
        row["db_id"], entry, db_dir, MERGER_INSTRUCTIONS.format(n=len(candidates)))
    user_msg = build_merger_user_message(row["question"], row.get("evidence", ""),
                                          candidates, examples_block)
    raw = await caller([{"role": "system", "content": system_prompt},
                         {"role": "user", "content": user_msg}])
    return {"merged_sql": clean_sql(raw), "reasoning": extract_reasoning(raw), "raw": raw}


async def run_phase4(dev: list[dict], schemas: dict, caller: AsyncCaller,
                      out_path: Path, retriever: Retriever, contrastive_bank: dict,
                      question_concurrency: int = 8, fewshot_scope: str = "samedb") -> None:
    done_ids = set()
    if out_path.exists():
        with out_path.open() as f:
            for line in f:
                if line.strip():
                    done_ids.add(json.loads(line)["question_id"])
    todo = [r for r in dev if r["question_id"] not in done_ids]
    print(f"[phase4] {len(dev)} total, {len(done_ids)} already done, {len(todo)} to run")
    if not todo:
        return

    async def _one(row: dict) -> dict:
        entry, db_dir = schemas[row["db_id"]]
        if fewshot_scope == "crossdb":
            # true cross-schema: k nearest EXCLUDING the question's own DB
            hard_ex = retriever.retrieve_hard_cross_db(row["question"], row["db_id"], k=K_HARD)
            examples_block = build_contrastive_block(hard_ex, contrastive_bank,
                                                     schemas=schemas, include_schema=True)
        elif fewshot_scope == "anypool":
            # whole-pool exemplars (any DB), each shown with its own schema
            hard_ex = retriever.retrieve_hard_any_db(row["question"], k=K_HARD)
            examples_block = build_contrastive_block(hard_ex, contrastive_bank,
                                                     schemas=schemas, include_schema=True)
        else:
            hard_ex = retriever.retrieve_hard_same_db(row["question"], row["db_id"], k=K_HARD)
            examples_block = build_contrastive_block(hard_ex, contrastive_bank)
        # stage 1: all 6 specialists in parallel.
        candidates = await run_specialists(row, entry, db_dir, caller,
                                           examples_block=examples_block)
        # stage 2: run the merger TWICE over the SAME candidates - once over all
        # 6, once over only the selector-chosen subset (select_skills; S1+S2
        # always included). Clean ablation of the merger's input set with the
        # candidate set held fixed. The two mergers run concurrently.
        selected = select_skills(row["question"])
        sel_cands = [c for c in candidates if c["id"] in selected]
        merger_all, merger_sel = await asyncio.gather(
            run_merger(row, candidates, caller, entry, db_dir, examples_block),
            run_merger(row, sel_cands, caller, entry, db_dir, examples_block),
        )
        res_all = score(row["db_id"], row["SQL"], merger_all["merged_sql"], split="dev")
        res_sel = score(row["db_id"], row["SQL"], merger_sel["merged_sql"], split="dev")
        return {
            "question_id": row["question_id"], "db_id": row["db_id"],
            "difficulty": row.get("difficulty", "unknown"),
            # entire trace: all 6 specialists' reasoning+sql+raw, both mergers'
            # reasoning+raw, and both final SQLs.
            "candidates": candidates, "selected": selected,
            # all-6 merger (primary field names - kept so summarize() and
            # recompute_ex_ves.py keep working for this variant)
            "merged_sql": merger_all["merged_sql"],
            "merger_reasoning": merger_all["reasoning"], "merger_raw": merger_all["raw"],
            # selector-subset merger
            "merged_sql_selected": merger_sel["merged_sql"],
            "merger_selected_reasoning": merger_sel["reasoning"],
            "merger_selected_raw": merger_sel["raw"],
            "match_selected": res_sel["match"],
            "pred_exec_ok_selected": res_sel.get("pred_exec_ok"),
            "pred_exec_err_selected": res_sel.get("pred_exec_err"),
            **res_all,
        }

    # Bound how many QUESTIONS are in flight at once (not just LLM calls): with
    # a single global call-semaphore, launching all questions at once starves
    # the mergers (each question's merger coros are created only after its
    # specialists return, so they queue behind every other question's specialist
    # calls and nothing completes until the very end). A per-question semaphore
    # keeps only a few questions open, so each finishes end-to-end promptly.
    from tqdm import tqdm  # noqa: E402
    q_sem = asyncio.Semaphore(question_concurrency)

    async def _guarded(row: dict) -> dict:
        async with q_sem:
            return await _one(row)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    # Write each question's result AS IT COMPLETES (incremental + resumable
    # mid-run): a sleep/crash keeps everything already finished.
    tasks = [asyncio.create_task(_guarded(r)) for r in todo]
    with out_path.open("a") as f:
        for fut in tqdm(asyncio.as_completed(tasks), total=len(tasks),
                        desc="phase4-specialists", ncols=80):
            r = await fut
            f.write(json.dumps(r) + "\n")
            f.flush()


def summarize(out_path: Path) -> dict:
    if not out_path.exists():
        return {}
    rows = [json.loads(l) for l in out_path.read_text().splitlines() if l.strip()]
    by_diff: dict = defaultdict(lambda: [0, 0])
    for r in rows:
        by_diff[r["difficulty"]][0] += int(r["match"])
        by_diff[r["difficulty"]][1] += 1
    overall = sum(v[0] for v in by_diff.values()), sum(v[1] for v in by_diff.values())
    return {
        "arm": "phase4_specialists", "n": overall[1],
        "execution_accuracy": overall[0] / overall[1] if overall[1] else None,
        "by_difficulty": {
            d: {"n": n, "execution_accuracy": acc / n if n else None}
            for d, (acc, n) in sorted(by_diff.items())
        },
    }


def print_summary(summary: dict) -> None:
    print(f"\n=== {summary['arm']} (n={summary['n']}) ===")
    print(f"  execution accuracy: {summary['execution_accuracy']:.3%}")
    for d, s in summary["by_difficulty"].items():
        print(f"    {d:12s} n={s['n']:5d}  {s['execution_accuracy']:.3%}")


async def _amain(limit: "int | None", max_concurrency: int, model_alias: str,
                  hard_dbs_only: bool, restrict_failed: "str | None",
                  question_concurrency: int, fewshot_scope: str) -> None:
    dev = load_dev()
    tag = ""
    if hard_dbs_only:
        dev = filter_to_hard_dbs(dev)
        tag = "_harddbs"
        print(f"[filter] restricted dev to the {len(hard_pool_db_ids())} db_ids "
              f"also in the hard pool -> {len(dev)} dev questions")
    if restrict_failed:
        # Keep only question_ids that a prior arm's run got WRONG (match falsey).
        # The output filename/tag is deliberately NOT changed, so a later full
        # run resumes from the same file and only makes the remaining calls.
        fp = Path(restrict_failed)
        failed = {json.loads(l)["question_id"]
                  for l in fp.read_text().splitlines()
                  if l.strip() and not int(json.loads(l).get("match", 0))}
        before = len(dev)
        dev = [r for r in dev if r["question_id"] in failed]
        print(f"[restrict-failed] {fp.name}: {len(failed)} failed ids -> "
              f"{len(dev)} of {before} dev questions kept")
    if limit:
        dev = dev[:limit]

    schemas = _schema_lookup()
    # max_concurrency governs total in-flight calls across all 8 roles per
    # question (7 parallel specialists + 1 merger), not per-question calls.
    caller = AsyncCaller(model_alias=model_alias, max_concurrency=max_concurrency,
                          max_tokens=1500)
    # The OpenAI client is synchronous (AsyncCaller uses asyncio.to_thread), so
    # true parallelism is bounded by the event loop's default thread pool
    # (~cpu_count+4). Enlarge it to match max_concurrency so all in-flight
    # specialist/merger calls actually run concurrently, not just ~14 at a time.
    import concurrent.futures
    asyncio.get_running_loop().set_default_executor(
        concurrent.futures.ThreadPoolExecutor(max_workers=max_concurrency + 8))

    # Same-db contrastive-proxy few-shot exemplars for every specialist.
    if not CONTRASTIVE_PROXY_BANK_PATH.exists():
        raise FileNotFoundError(
            f"{CONTRASTIVE_PROXY_BANK_PATH} missing - run "
            "`python3 generation/build_contrastive_bank_proxy.py` first.")
    contrastive_bank = json.loads(CONTRASTIVE_PROXY_BANK_PATH.read_text())
    retriever = Retriever()

    # Whole-pool/cross-schema few-shot writes to its own file so the same-db
    # results are preserved for comparison.
    if fewshot_scope == "anypool":
        tag += "_anypoolschema"
    elif fewshot_scope == "crossdb":
        tag += "_crossdbschema"
    out_dir = OUT_DIR / model_subdir(model_alias)
    out_path = out_dir / f"phase4_specialists{tag}.jsonl"
    await run_phase4(dev, schemas, caller, out_path, retriever, contrastive_bank,
                      question_concurrency=question_concurrency, fewshot_scope=fewshot_scope)
    summary = summarize(out_path)
    print_summary(summary)

    out_dir.mkdir(parents=True, exist_ok=True)
    summary_path = out_dir / f"phase4_summary{tag}.json"
    summary_path.write_text(json.dumps(summary, indent=2))
    print(f"\nwrote {summary_path}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=None)
    ap.add_argument("--max-concurrency", type=int, default=16,
                     help="total in-flight calls (6 specialists run in parallel "
                          "per question, so a higher default than other phases "
                          "keeps multiple questions in flight too)")
    ap.add_argument("--model", default="gpt-5.6-luna",
                     help="model label used only for the results subfolder name; the "
                          "proxy backend always serves gpt-5.6-luna")
    ap.add_argument("--hard-dbs-only", action="store_true",
                     help="restrict dev to the 6 db_ids also in the hard pool")
    ap.add_argument("--restrict-failed", default=None,
                     help="path to a run/ex_ves jsonl; keep only question_ids whose "
                          "match is falsey (i.e. run the pipeline only on the "
                          "questions that arm failed). Output file is unchanged, so a "
                          "later full run resumes and only does the remaining questions.")
    ap.add_argument("--question-concurrency", type=int, default=8,
                     help="how many QUESTIONS may be in flight at once; bounds each "
                          "question end-to-end (specialists+mergers) so mergers aren't "
                          "starved and progress/writes are steady. LLM-call concurrency "
                          "is still capped by --max-concurrency.")
    ap.add_argument("--fewshot-scope", choices=["samedb", "anypool", "crossdb"], default="samedb",
                     help="samedb (default): 5 same-database exemplars. anypool: 5 whole-pool "
                          "exemplars (any DB). crossdb: 5 nearest EXCLUDING the question's own "
                          "DB (true cross-schema). anypool/crossdb attach each exemplar's schema "
                          "(grouped by DB) and write to a separate *_<scope>schema output file.")
    args = ap.parse_args()
    asyncio.run(_amain(args.limit, args.max_concurrency, args.model, args.hard_dbs_only,
                        args.restrict_failed, args.question_concurrency, args.fewshot_scope))


if __name__ == "__main__":
    main()
