"""
selector_tier1.py — Execution-based candidate selector for Phase 4 (NO LLM
calls, NO dev leakage). Combines three techniques over the ALREADY-GENERATED
specialist candidates, choosing among them purely by executing SQL locally:

  (1) CONFIDENCE-WEIGHTED VOTE. Each agent's vote is weighted by the taxonomy
      coverage its specialist targets. These weights come from the TRAIN-pool
      error taxonomy (222 train-pool failures, generation/taxonomy_clusters.json)
      - a design-time prior mined from train, never from the held-out dev set,
      so no leakage.
  (2) EXECUTION-QUALITY GATING. Candidates that error / time out / return an
      oversized result are excluded from the vote; if none survive, fall back
      to the merger.
  (3) LITERAL GROUNDING. For each `col = 'literal'` filter, probe whether the
      literal actually exists in the referenced column. A candidate that filters
      on a provably-absent literal is downweighted (targets the S2 literal-match
      failure mode). Undetermined cases are never penalized (conservative).

Ties (no unique top cluster) or all-invalid -> the merger's already-saved SQL
(no new LLM call). Everything is a fixed, a-priori rule; nothing is tuned on
dev. This scores the completed 4.8 batch as a single held-out read-out.

Usage:  python3 selector_tier1.py --model 4.8
"""

from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import os
import sqlite3
import sys
import time
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import sqlglot
from sqlglot import exp

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DEV_PATH = ROOT / "data" / "bird" / "dev" / "dev.json"
sys.path.insert(0, str(ROOT / "generation"))
from execution import db_path_for  # noqa: E402

AGENT_IDS = ["S1", "S2", "S3", "S4", "S5", "S6"]
# Taxonomy-coverage priors (train-pool mined failure counts, /222). NOT fit to
# dev - a design-time prior. Used as vote weights.
AGENT_WEIGHT = {"S1": 109, "S2": 70, "S3": 15, "S4": 13, "S5": 8, "S6": 7}
UNGROUNDED_FACTOR = 0.3   # fixed a-priori penalty for a provably-absent literal
TIMEOUT_S = 20
ROW_CAP = 100_000
_PROGRESS_STEPS = 1000
MAX_PREDS = 6             # cap literal probes per candidate (bounds work)


def _connect(db_id: str):
    con = sqlite3.connect(f"file:{db_path_for(db_id, 'dev')}?mode=ro", uri=True)
    con.text_factory = lambda b: b.decode(errors="replace")
    start = time.monotonic()
    con.set_progress_handler(
        lambda: 1 if (time.monotonic() - start) > TIMEOUT_S else 0, _PROGRESS_STEPS)
    return con


def result_signature(con, sql: str):
    """frozenset(rows) (BIRD set-equality), or None on error/timeout/oversized/empty-sql."""
    if not sql or not sql.strip():
        return None
    try:
        cur = con.execute(sql)
        rows = cur.fetchmany(ROW_CAP + 1)
        if len(rows) > ROW_CAP:
            return None
        return frozenset(rows)
    except Exception:
        return None


def _eq_literal_predicates(sql: str):
    """[(column, literal), ...] for `col = 'literal'` predicates, plus the
    query's table names. None if the SQL can't be parsed (then: don't ground)."""
    try:
        tree = sqlglot.parse_one(sql, read="sqlite")
    except Exception:
        return None
    preds = []
    for eq in tree.find_all(exp.EQ):
        for a, b in ((eq.this, eq.expression), (eq.expression, eq.this)):
            if isinstance(a, exp.Column) and isinstance(b, exp.Literal) and b.is_string:
                preds.append((a.name, b.this))
    tables = [t.name for t in tree.find_all(exp.Table) if t.name]
    return preds[:MAX_PREDS], list(dict.fromkeys(tables))


def is_grounded(con, sql: str) -> bool:
    """False only if some filter literal is PROVABLY absent from every table we
    could check; True when grounded or undetermined (conservative - never
    penalize on uncertainty)."""
    parsed = _eq_literal_predicates(sql)
    if parsed is None:
        return True
    preds, tables = parsed
    if not preds or not tables:
        return True
    for col, lit in preds:
        determined, found = False, False
        for tbl in tables:
            try:
                cur = con.execute(f'SELECT 1 FROM "{tbl}" WHERE "{col}" = ? LIMIT 1', (lit,))
                determined = True
                if cur.fetchone() is not None:
                    found = True
                    break
            except Exception:
                continue  # bad table/col for this pairing - undetermined
        if determined and not found:
            return False
    return True


def _one(args: tuple) -> tuple:
    qid, db_id, difficulty, gold_sql, agent_sqls, merger_sql = args
    con = _connect(db_id)
    try:
        gold_sig = result_signature(con, gold_sql)
        merger_sig = result_signature(con, merger_sql)
        # per-candidate: signature + grounding-adjusted weight
        cluster_w = defaultdict(float)
        any_valid = False
        for aid, sql in zip(AGENT_IDS, agent_sqls):
            sig = result_signature(con, sql)
            if sig is None:                      # gating: drop error/timeout/oversized
                continue
            any_valid = True
            w = AGENT_WEIGHT[aid]
            if not is_grounded(con, sql):        # literal-grounding penalty
                w *= UNGROUNDED_FACTOR
            cluster_w[sig] += w
    finally:
        con.close()

    if not any_valid:
        route, chosen = "fallback", merger_sig
    else:
        ranked = sorted(cluster_w.items(), key=lambda kv: kv[1], reverse=True)
        if len(ranked) == 1 or ranked[0][1] > ranked[1][1]:
            route, chosen = "agree", ranked[0][0]
        else:
            route, chosen = "fallback", merger_sig   # tie -> merger
    match = int(chosen is not None and gold_sig is not None and chosen == gold_sig)
    return difficulty, route, match


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="4.8")
    ap.add_argument("--workers", type=int, default=8)
    args = ap.parse_args()

    dev = {r["question_id"]: r for r in json.loads(DEV_PATH.read_text())}
    rows = [json.loads(l) for l in (HERE / "runs" / args.model /
            "phase4_specialists.jsonl").read_text().splitlines() if l.strip()]
    tasks = []
    for r in rows:
        by_id = {c["id"]: c["sql"] for c in r["candidates"]}
        tasks.append((r["question_id"], r["db_id"], r.get("difficulty", "unknown"),
                      dev[r["question_id"]]["SQL"],
                      [by_id.get(a, "") for a in AGENT_IDS], r["merged_sql"]))

    from tqdm import tqdm
    results, n_timeout = {}, 0
    pool = ProcessPoolExecutor(max_workers=args.workers)
    futs = {pool.submit(_one, t): i for i, t in enumerate(tasks)}
    pending, last = set(futs), time.monotonic()
    with tqdm(total=len(futs), desc="selector-tier1", ncols=80) as bar:
        while pending:
            done, pending = cf.wait(pending, timeout=30, return_when=cf.FIRST_COMPLETED)
            if done:
                last = time.monotonic()
                for fut in done:
                    results[futs[fut]] = fut.result(); bar.update(1)
            elif time.monotonic() - last > 120:
                break
    for fut, i in futs.items():
        if i not in results:
            results[i] = (tasks[i][2], "timeout", 0); n_timeout += 1
    pool.shutdown(wait=False, cancel_futures=True)
    if n_timeout:
        print(f"[warn] {n_timeout} question(s) hung -> counted incorrect")
    out = [results[i] for i in range(len(tasks))]

    n = len(out)
    ex = sum(m for _, _, m in out) / n
    by_diff, by_route = defaultdict(lambda: [0, 0]), defaultdict(lambda: [0, 0])
    for diff, route, m in out:
        by_diff[diff][0] += m; by_diff[diff][1] += 1
        by_route[route][0] += m; by_route[route][1] += 1
    agree = by_route["agree"][1]
    print(f"Tier-1 selector ({args.model}), N={n}")
    print(f"  EX: {ex:.1%}")
    print(f"  agreed via execution (no merger): {agree}/{n} ({agree/n:.1%})  "
          f"merger fallback: {n-agree}/{n}")
    for r in ("agree", "fallback", "timeout"):
        c, t = by_route[r]
        if t:
            print(f"    route={r:9s} n={t:5d}  EX {c/t:.1%}")
    for d in ("simple", "moderate", "challenging"):
        if by_diff[d][1]:
            c, t = by_diff[d]
            print(f"    {d:12s} n={t:5d}  EX {c/t:.1%}")
    sys.stdout.flush()
    os._exit(0)


if __name__ == "__main__":
    main()
