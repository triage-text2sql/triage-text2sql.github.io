"""
synsql_pool.py — Exemplar pool sourced from an external synthetic dataset
(seeklhy/SynSQL-2.5M on the HF Hub) instead of BIRD's own train/hard pools.

Used to isolate whether few-shot gains come from BIRD-specific exemplars or
from any semantically-relevant (question, SQL) pair, regardless of provenance
or schema. Mirrors data_bird/hard_pool.py's load-once, normalize-into-
{question, sql, db_id, evidence} contract.

SynSQL-2.5M ships as a single ~9.3GB JSON array (2.5M rows, ~16k synthetic
databases) with no HF datasets-server / parquet mirror available, so we
stream the whole file with ijson (never buffering it in memory) and cache it
locally as JSONL (~2.5GB). This is a one-time, ~45-90 minute download - run
it explicitly (see data_bird/build_synsql_index.py) rather than triggering it
lazily inside a live experiment run.
"""

from __future__ import annotations

import json
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
CACHE_DIR = HERE / "synsql"
CACHE_PATH = CACHE_DIR / "synsql_pool.jsonl"
COMPLETE_MARKER = CACHE_DIR / "synsql_pool.complete"

SYNSQL_URL = "https://huggingface.co/datasets/seeklhy/SynSQL-2.5M/resolve/main/data.json"
LOG_EVERY = 50_000


def _download(n: "int | None", out_path: Path) -> None:
    import ijson
    import requests

    limit_desc = f"first {n}" if n else "all ~2.5M"
    print(f"[synsql_pool] streaming {limit_desc} records from {SYNSQL_URL} ...", flush=True)
    t0 = time.time()
    r = requests.get(SYNSQL_URL, stream=True, timeout=60)
    r.raise_for_status()
    r.raw.decode_content = True
    out_path.parent.mkdir(parents=True, exist_ok=True)
    written = 0
    hit_cap = False
    tmp_path = out_path.with_suffix(".jsonl.tmp")
    with tmp_path.open("w") as f:
        for it in ijson.items(r.raw, "item"):
            row = {
                "question": it["question"],
                "sql": it["sql"],
                "db_id": it["db_id"],
                "evidence": it.get("external_knowledge", ""),
            }
            f.write(json.dumps(row) + "\n")
            written += 1
            if written % LOG_EVERY == 0:
                elapsed = time.time() - t0
                print(f"[synsql_pool] {written} rows in {elapsed:.0f}s "
                      f"({written / elapsed:.0f} rows/s)", flush=True)
            if n and written >= n:
                hit_cap = True
                break
    r.close()
    tmp_path.replace(out_path)
    print(f"[synsql_pool] done: cached {written} rows -> {out_path} "
          f"({time.time() - t0:.0f}s total)", flush=True)
    if n is None or not hit_cap:
        # Only mark "complete" if the source stream was actually exhausted -
        # a capped partial download (smoke testing) must never be mistaken
        # for the full dataset by a later n=None ("give me everything") call.
        COMPLETE_MARKER.write_text(str(written))


def load_synsql_pool(n: "int | None" = None) -> list[dict]:
    """Returns [{question, sql, db_id, evidence}, ...]. Downloads and caches
    the full SynSQL-2.5M dataset under data_bird/synsql/ on first use (a
    one-time ~45-90 min job - see build_synsql_index.py). Pass `n` to cap the
    download for smoke testing only; a capped cache is never reused for a
    later full (`n=None`) request."""
    if n is None:
        if COMPLETE_MARKER.exists() and CACHE_PATH.exists():
            return [json.loads(l) for l in CACHE_PATH.read_text().splitlines() if l.strip()]
        _download(None, CACHE_PATH)
        return [json.loads(l) for l in CACHE_PATH.read_text().splitlines() if l.strip()]

    if CACHE_PATH.exists():
        rows = [json.loads(l) for l in CACHE_PATH.read_text().splitlines() if l.strip()]
        if len(rows) >= n:
            return rows[:n]
    _download(n, CACHE_PATH)
    rows = [json.loads(l) for l in CACHE_PATH.read_text().splitlines() if l.strip()]
    return rows[:n]
