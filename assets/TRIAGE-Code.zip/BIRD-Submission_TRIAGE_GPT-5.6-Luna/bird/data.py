"""
data.py — Shared dev-set loading + hard-pool db_id filtering for Phases 1/3/4.
Small deliberate duplication of judge/run_calibration_ladder.py's equivalent
helpers, kept separate so generation/ doesn't depend on a judge/ CLI script.

The hard-pool db_id set is derived from data_bird/hard_pool.py's unified
loader (both source files), so it now spans all 11 dev databases - the 6
originally covered by hard/hard_merged.jsonl plus the 5 filled in by
generation/BIRD_More_Hard_Questions_Using_Unused_Dev_DBs.jsonl.
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
DATA_BIRD = HERE.parent / "data" / "bird"
DEV_PATH = DATA_BIRD / "dev" / "dev.json"

sys.path.insert(0, str(HERE))
from hard_pool import load_hard_pool  # noqa: E402
from models import resolve_model  # noqa: E402


def model_subdir(model_alias: str) -> str:
    """Short per-model results subfolder name, so each model's runs live under
    runs/<version>/ (e.g. runs/4.7/, runs/4.8/) instead of colliding by
    filename. Derives the version from the resolved model id
    (gpt-5.6-luna -> "5.6"); falls back to a filename-safe model id."""
    resolved = resolve_model(model_alias)
    m = re.search(r"(\d+\.\d+)", resolved)
    return m.group(1) if m else resolved.replace(".", "-").replace("/", "-")


def load_dev() -> list[dict]:
    return json.loads(DEV_PATH.read_text())


def hard_pool_db_ids() -> set[str]:
    """db_ids present in the unified hard pool - all 11 dev databases
    (data_bird/hard_pool.py unions hard_merged.jsonl's 6 dbs with the 5-db
    BIRD_More_Hard_Questions_Using_Unused_Dev_DBs.jsonl top-up)."""
    return {r["db_id"] for r in load_hard_pool()}


def filter_to_hard_dbs(dev: list[dict]) -> list[dict]:
    """Restrict dev rows to the db_ids present in the hard pool. With the
    5-db top-up merged in, this now covers all 11 dev databases (the full
    1,534 dev questions) rather than the original 6-db / 882-question slice."""
    dbs = hard_pool_db_ids()
    return [r for r in dev if r["db_id"] in dbs]
