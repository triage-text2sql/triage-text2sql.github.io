"""
hard_pool.py — Single shared loader for the "hard pool" exemplar source,
used by judge/retrieval.py, judge/build_proxy_hard_bank.py,
generation/build_contrastive_bank.py, and generation/build_contrastive_bank_proxy.py
so none of them duplicate this union-and-clean logic.

Two source files, same schema (id, db_id, question, sql, ...):
  data_bird/hard/hard_merged.jsonl                              726 questions,
      6 dbs (codebase_community, european_football_2, financial, formula_1,
      student_club, superhero).
  generation/BIRD_More_Hard_Questions_Using_Unused_Dev_DBs.jsonl 100 questions,
      the other 5 dev dbs (california_schools, card_games,
      debit_card_specializing, thrombosis_prediction, toxicology) - fills the
      gap so every one of the 11 dev databases now has same-db hard-pool
      exemplar coverage.

Both files' SQL is 100% contaminated with a synthetic-generation artifact:
every single row has `LIMIT 200` appended and every identifier double-quoted
(confirmed: 726/726 and 100/100). Neither reflects the actual question's
real requirements - it's a uniform habit of whatever template pipeline
produced this data - and previously leaked into Phase 3 exemplars verbatim,
teaching the model to imitate a style foreign to BIRD's own gold-SQL
convention. clean_sql() strips both before this data is ever used as
exemplar material.
"""

from __future__ import annotations

import json
from pathlib import Path

import re

import sqlglot
from sqlglot import exp

DATA_BIRD = Path(__file__).resolve().parent.parent / "data" / "bird"
HARD_POOL_PATHS = [
    DATA_BIRD / "hard" / "hard_merged.jsonl",
    DATA_BIRD / "hard" / "BIRD_More_Hard_Questions_Using_Unused_Dev_DBs.jsonl",
]

_BARE_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def clean_sql(sql: str, dialect: str = "sqlite") -> str:
    """Strips the hard pool's synthetic-generation artifacts: drop any LIMIT
    clause, de-quote identifiers that don't need it. Some schemas (e.g.
    california_schools) have genuinely space-containing column names
    ("Charter Funding Type") that MUST stay quoted to remain valid SQL - only
    identifiers matching a plain [A-Za-z_][A-Za-z0-9_]* pattern have their
    quoting stripped, so necessary escaping survives. Falls back to the raw
    string if the query fails to parse (rare, defensive only)."""
    try:
        tree = sqlglot.parse_one(sql, dialect=dialect)
    except Exception:
        return sql
    limit = tree.find(exp.Limit)
    if limit is not None:
        limit.pop()
    for ident in tree.find_all(exp.Identifier):
        if _BARE_IDENTIFIER.match(ident.this):
            ident.set("quoted", False)
    return tree.sql(dialect=dialect)


def load_hard_pool() -> list[dict]:
    """Returns [{question, db_id, sql (cleaned)}, ...] across both source
    files, 826 rows total covering all 11 dev databases."""
    items = []
    for path in HARD_POOL_PATHS:
        with path.open() as f:
            for line in f:
                if not line.strip():
                    continue
                r = json.loads(line)
                items.append({
                    "question": r["question"], "db_id": r["db_id"],
                    "sql": clean_sql(r["SQL"] if "SQL" in r else r["sql"]),
                })
    return items
