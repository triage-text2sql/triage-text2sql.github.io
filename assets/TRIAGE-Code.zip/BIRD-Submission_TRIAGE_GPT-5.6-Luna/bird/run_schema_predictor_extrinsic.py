"""
run_schema_predictor_extrinsic.py — Experiment 2 (extrinsic test) of the
schema-linking follow-up plan: plug the schema-predictor agent's predicted
schema into the merger (same paired baseline-vs-X harness used all session),
full scale.

Reuses cached predictions from run_schema_predictor_intrinsic.py's output
(schema_predictor_intrinsic.jsonl) where available (0 new calls for those
question_ids); predicts fresh for every other sampled question. Same
predicted-schema rendering approach as the oracle-schema experiment (lean
table/column/type/[PK] renderer, PK/FK safety net for joins between two
predicted tables), but the table/column set comes from the schema-predictor
agent instead of gold SQL. Cross-schema few-shot throughout (standing rule).

Two merges per question, paired on identical inputs otherwise:
  baseline_sql       — merger sees the FULL per-db schema, cross-schema fewshot
  predicted_schema_sql — merger sees ONLY the predictor's predicted tables/
                         columns (+ PK/FK safety net), cross-schema fewshot
Specialists, executed-result previews, and exemplars are otherwise identical.

Usage:
  python3 run_schema_predictor_extrinsic.py --n 1534 --seed 0 --k-train 5 \
      --model-alias gpt-5.6-luna --workers 8
"""
from __future__ import annotations

import argparse
import asyncio
import json
import random
import sys
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
for p in ("generation", "judge", "data_bird"):
    sys.path.insert(0, str(ROOT / p))
sys.path.insert(0, str(HERE))

from generator_prompt import clean_sql                                       # noqa: E402
from schema_utils import iter_all_schemas, load_schema_graphs                 # noqa: E402
from llm_call import AsyncCaller, gather_with_progress                       # noqa: E402
from retrieval import Retriever                                              # noqa: E402
from selector_tier1 import _connect, result_signature                        # noqa: E402
from run_phase4_specialists import build_contrastive_block, CONTRASTIVE_PROXY_BANK_PATH  # noqa: E402
from exec_feedback_pilot import EXEC_MERGER_TASK, build_merger_msg, _preview  # noqa: E402
from run_oracle_merger_pilot import (filter_entry_to_oracle, render_oracle_schema,  # noqa: E402
                                      build_full_merger_system_prompt)
from schema_utils import render_foreign_keys                                 # noqa: E402
from run_schema_predictor_intrinsic import (build_predictor_messages,        # noqa: E402
                                             parse_prediction, extract_oracle_schema)

DEV_PATH = ROOT / "data" / "bird" / "dev" / "dev.json"
SPECIALISTS_PATH = HERE / "runs" / "4.8" / "phase4_specialists.jsonl"
INTRINSIC_CACHE_PATH = HERE / "runs" / "4.8" / "schema_predictor_intrinsic.jsonl"
OUT_PATH = HERE / "runs" / "4.8" / "schema_predictor_extrinsic.jsonl"


def build_predicted_merger_system_prompt(db_id: str, filtered_entry: dict, merger_task: str) -> str:
    schema_str = render_oracle_schema(filtered_entry)
    fk_str = render_foreign_keys(filtered_entry)
    hop_note = ("(schema restricted to the tables/columns a gold-free schema-"
                "linking agent predicted are needed - any join you need is "
                "one of the FOREIGN KEYS above)")
    return f"""You are an expert SQLite SQL merger for the database "{db_id}".

--- DATABASE SCHEMA -----------------------------------------------------------

{schema_str}

--- FOREIGN KEYS --------------------------------------------------------------

{fk_str}

--- JOIN GRAPH / MULTI-HOP PATHS ----------------------------------------------

{hop_note}

--- YOUR TASK ---------------------------------------------------------------

{merger_task}"""


def add_fk_safety_net(entry: dict, tables: set, cols_by_table: dict) -> dict:
    for col_a, col_b in entry.get("foreign_keys", []):
        ta_idx, na = entry["column_names_original"][col_a]
        tb_idx, nb = entry["column_names_original"][col_b]
        ta_name = entry["table_names_original"][ta_idx].lower()
        tb_name = entry["table_names_original"][tb_idx].lower()
        if ta_name in tables and tb_name in tables:
            cols_by_table.setdefault(ta_name, set()).add(na.lower())
            cols_by_table.setdefault(tb_name, set()).add(nb.lower())
    return cols_by_table


def score_against_gold(db_id: str, gold_sql: str, sql: str) -> bool:
    con = _connect(db_id)
    try:
        gold = result_signature(con, gold_sql)
        got = result_signature(con, sql)
        if gold is None or got is None:
            return False
        return got == gold
    finally:
        con.close()


async def _amain(n: int, seed: int, k_train: int, model_dir: str, model_alias: str, workers: int):
    dev_list = json.loads(DEV_PATH.read_text())
    dev = {r["question_id"]: r for r in dev_list}
    recs = {json.loads(l)["question_id"]: json.loads(l)
            for l in SPECIALISTS_PATH.read_text().splitlines() if l.strip()}

    random.seed(seed)
    sample_ids = [r["question_id"] for r in random.sample(dev_list, n)]

    cached_preds = {}
    if INTRINSIC_CACHE_PATH.exists():
        for l in INTRINSIC_CACHE_PATH.read_text().splitlines():
            if l.strip():
                row = json.loads(l)
                cached_preds[row["question_id"]] = {
                    "tables": set(row["pred_tables"]),
                    "columns": {(c.split(".", 1)[0], c.split(".", 1)[1]) for c in row["pred_columns"]},
                }
    print(f"[cache] {len(cached_preds)} predictions already cached, reusing where sampled")

    schemas = {db: (e, dd) for db, e, dd in iter_all_schemas()}
    schema_graphs = load_schema_graphs()
    retriever = Retriever()
    contrastive = json.loads(CONTRASTIVE_PROXY_BANK_PATH.read_text())
    caller = AsyncCaller(model_alias=model_alias, max_concurrency=workers, max_tokens=1500)
    predictor_caller = AsyncCaller(model_alias=model_alias, max_concurrency=workers, max_tokens=1200)

    stats = []

    async def _process(qid: int):
        d = dev[qid]
        rec = recs[qid]
        db_id = rec["db_id"]
        entry, db_dir = schemas[db_id]

        # -- predicted schema: reuse cache, else predict fresh --
        if qid in cached_preds:
            pred = cached_preds[qid]
        else:
            q_emb = retriever.embedder.encode([d["question"]], convert_to_tensor=True,
                                               normalize_embeddings=True)[0]
            exemplars = retriever.train_pool.top_k(q_emb, k_train, exclude_exact=d["question"])
            sysp, userp = build_predictor_messages(d, entry, db_dir, exemplars, schemas)
            raw = await predictor_caller([{"role": "system", "content": sysp},
                                           {"role": "user", "content": userp}])
            pred = parse_prediction(raw)

        pred_tables = set(pred["tables"])
        pred_cols_by_table = defaultdict(set)
        for t, c in pred["columns"]:
            pred_cols_by_table[t].add(c)
            pred_tables.add(t)     # a column implies its table, even if "tables" missed it
        pred_cols_by_table = add_fk_safety_net(entry, pred_tables, dict(pred_cols_by_table))

        n_total_tables = len(entry["table_names_original"])
        n_total_cols = len(entry["column_names_original"])
        filtered_entry = filter_entry_to_oracle(entry, pred_tables, pred_cols_by_table)
        if filtered_entry is None:
            filtered_entry = entry
            n_pt, n_pc = n_total_tables, n_total_cols
        else:
            n_pt = len(filtered_entry["table_names_original"])
            n_pc = len(filtered_entry["column_names_original"])
        stats.append((n_pt, n_total_tables, n_pc, n_total_cols))

        # -- candidates + cross-db exemplars (shared by both merges) --
        con = _connect(db_id)
        try:
            cand_prev = []
            for c in rec["candidates"]:
                status, _ = _preview(con, c["sql"])
                cand_prev.append({"id": c["id"], "sql": c["sql"],
                                   "reasoning": (c.get("reasoning") or "")[:400], "result": status})
        finally:
            con.close()

        hard_ex = retriever.retrieve_hard_cross_db(d["question"], db_id, k=5)
        examples = build_contrastive_block(hard_ex, contrastive, schemas=schemas, include_schema=True)
        merger_rec = {"question": d["question"], "evidence": d.get("evidence", ""), "candidates": cand_prev}
        user_msg = build_merger_msg(merger_rec, examples)

        sysp_full = build_full_merger_system_prompt(db_id, entry, db_dir, EXEC_MERGER_TASK, schema_graphs)
        sysp_pred = build_predicted_merger_system_prompt(db_id, filtered_entry, EXEC_MERGER_TASK)

        raw_base, raw_pred = await asyncio.gather(
            caller([{"role": "system", "content": sysp_full}, {"role": "user", "content": user_msg}]),
            caller([{"role": "system", "content": sysp_pred}, {"role": "user", "content": user_msg}]))
        return clean_sql(raw_base), clean_sql(raw_pred)

    print(f"[merge] running baseline + predicted-schema merges for {n} questions "
          f"(cross-schema fewshot, specialists 100% reused)...")
    pairs = await gather_with_progress([_process(qid) for qid in sample_ids], desc="pred-schema-merge")

    base_correct = [score_against_gold(dev[qid]["db_id"], dev[qid]["SQL"], b) for qid, (b, p) in zip(sample_ids, pairs)]
    pred_correct = [score_against_gold(dev[qid]["db_id"], dev[qid]["SQL"], p) for qid, (b, p) in zip(sample_ids, pairs)]

    rows = []
    for qid, (b, p), bok, pok, (n_pt, n_tt, n_pc, n_tc) in zip(sample_ids, pairs, base_correct, pred_correct, stats):
        d = dev[qid]
        rows.append({"question_id": qid, "db_id": d["db_id"], "difficulty": d.get("difficulty"),
                     "baseline_sql": b, "baseline_correct": bok, "predicted_schema_sql": p,
                     "predicted_schema_correct": pok, "n_pred_tables": n_pt, "n_total_tables": n_tt,
                     "n_pred_cols": n_pc, "n_total_cols": n_tc})
    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with OUT_PATH.open("w") as f:
        for row in rows:
            f.write(json.dumps(row) + "\n")

    n_base_ok, n_pred_ok = sum(base_correct), sum(pred_correct)
    gained = sum(1 for b, p in zip(base_correct, pred_correct) if not b and p)
    harmed = sum(1 for b, p in zip(base_correct, pred_correct) if b and not p)
    unchanged_ok = sum(1 for b, p in zip(base_correct, pred_correct) if b and p)
    unchanged_bad = sum(1 for b, p in zip(base_correct, pred_correct) if not b and not p)

    by_diff_base = defaultdict(lambda: [0, 0])
    by_diff_pred = defaultdict(lambda: [0, 0])
    for qid, bok, pok in zip(sample_ids, base_correct, pred_correct):
        d = dev[qid]["difficulty"]
        by_diff_base[d][0] += int(bok); by_diff_base[d][1] += 1
        by_diff_pred[d][0] += int(pok); by_diff_pred[d][1] += 1

    avg_pt = sum(t[0] for t in stats) / n
    avg_tt = sum(t[1] for t in stats) / n

    print(f"\n=== Schema-predictor extrinsic (merger) test (N={n}, seed={seed}) ===")
    print(f"  baseline (full schema)                EX: {n_base_ok/n:.1%}  ({n_base_ok}/{n})")
    print(f"  predicted-schema merger                EX: {n_pred_ok/n:.1%}  ({n_pred_ok}/{n})")
    print(f"  gained (wrong->right): {gained}   harmed (right->wrong): {harmed}")
    print(f"  unchanged correct: {unchanged_ok}   unchanged wrong: {unchanged_bad}")
    print(f"  avg tables shown: predicted {avg_pt:.1f} vs full {avg_tt:.1f}")
    print(f"\n  by difficulty (baseline -> predicted):")
    for d in sorted(set(by_diff_base) | set(by_diff_pred)):
        bc, bt = by_diff_base[d]
        pc, pt = by_diff_pred[d]
        print(f"    {d:12s} n={bt:3d}  {bc/bt:.1%} -> {pc/pt:.1%}")
    print(f"\nwrote {OUT_PATH}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=1534)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--k-train", type=int, default=5)
    ap.add_argument("--model", default="4.8")
    ap.add_argument("--model-alias", default="gpt-5.6-luna")
    ap.add_argument("--workers", type=int, default=8)
    args = ap.parse_args()
    asyncio.run(_amain(args.n, args.seed, args.k_train, args.model, args.model_alias, args.workers))


if __name__ == "__main__":
    main()
