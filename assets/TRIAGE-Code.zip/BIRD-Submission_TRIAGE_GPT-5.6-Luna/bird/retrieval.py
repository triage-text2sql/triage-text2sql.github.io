"""
retrieval.py — Embedding-based nearest-neighbor retrieval over the train pool
(9,428 questions, real gold SQL) and the hard pool (826 questions across all
11 dev databases, see data_bird/hard_pool.py), shared by all 4 experiments of
the calibration ladder.

Retrieval is deterministic top-k by cosine similarity (all-MiniLM-L6-v2,
same embedder as judge/judge_best.py) — nothing here is randomly sampled.
Embeddings are cached under judge/cache/ and rebuilt only when the source
train.json / hard pool files are newer than the cache.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import torch
from sentence_transformers import SentenceTransformer

HERE = Path(__file__).resolve().parent
DATA_BIRD = HERE.parent / "data" / "bird"
TRAIN_PATH = DATA_BIRD / "train" / "train.json"
CACHE_DIR = HERE / "cache"

sys.path.insert(0, str(HERE))
from hard_pool import HARD_POOL_PATHS, load_hard_pool  # noqa: E402
from synsql_pool import load_synsql_pool  # noqa: E402

EMBED_MODEL_NAME = "all-MiniLM-L6-v2"
K_TRAIN = 2
K_HARD = 3
K_SYNSQL = 5
SYNSQL_FAISS_INDEX_PATH = CACHE_DIR / "synsql_faiss.index"
SYNSQL_TOPK_CACHE_PATH = DATA_BIRD / "synsql" / "synsql_top5_by_question.json"
# Size-matched control: a random SynSQL subsample the SAME size as the BIRD
# hard pool (826), so synsql_fewshot_matched isolates whether synsql_fewshot's
# edge over gold_fewshot/proxy is from SynSQL's per-item quality/diversity or
# just a pool-size artifact (2.5M candidates vs. 826 - a bigger haystack
# finds closer nearest-neighbor matches almost mechanically, regardless of
# per-item quality). Fixed seed - deterministic, reproducible.
SYNSQL_POOL_JSONL_PATH = DATA_BIRD / "synsql" / "synsql_pool.jsonl"
SYNSQL_MATCHED_POOL_PATH = DATA_BIRD / "synsql" / "synsql_matched_pool.jsonl"
SYNSQL_MATCHED_SEED = int(os.environ.get("SYNSQL_MATCHED_SEED", "42"))
# Hard+Extra-Hard-filtered control (see data_bird/sql_hardness.py and
# build_synsql_hard_pool.py): same size-matched-subsample idea as
# SYNSQL_MATCHED_*, but sampled only from SynSQL rows whose SQL classifies as
# Hard/Extra-Hard, isolating whether exemplar SQL complexity (not just pool
# size) drives synsql_fewshot_matched's edge. Separate constants/cache files
# throughout so this never collides with or perturbs the existing
# (uniform-random) matched pool's cached files or run provenance.
SYNSQL_HARD_POOL_JSONL_PATH = DATA_BIRD / "synsql" / "synsql_hard_pool.jsonl"
SYNSQL_MATCHED_HARD_POOL_PATH = DATA_BIRD / "synsql" / "synsql_matched_hard_pool.jsonl"
SYNSQL_MATCHED_HARD_POOL_META_PATH = (DATA_BIRD / "synsql"
                                      / "synsql_matched_hard_pool.meta.json")
SYNSQL_MATCHED_HARD_SEED = int(os.environ.get("SYNSQL_MATCHED_HARD_SEED", "42"))


def _best_device() -> str:
    if torch.backends.mps.is_available():
        return "mps"
    if torch.cuda.is_available():
        return "cuda"
    return "cpu"


def _norm(q: str) -> str:
    return " ".join(q.strip().lower().split())


def _load_train() -> list[dict]:
    rows = json.loads(TRAIN_PATH.read_text())
    return [
        {"question": r["question"], "sql": r["SQL"], "db_id": r["db_id"],
         "evidence": r.get("evidence", "")}
        for r in rows
    ]


def _load_hard() -> list[dict]:
    return load_hard_pool()


def _build_synsql_matched_pool(n: int) -> list[dict]:
    """Streams the full 2.54M-row SynSQL pool once, picking exactly n
    deterministically-random rows (index set drawn up front via a seeded
    RNG, so this is reproducible without loading the whole 2.5GB file into
    memory at once)."""
    import random

    with SYNSQL_POOL_JSONL_PATH.open() as f:
        total = sum(1 for _ in f)
    want = set(random.Random(SYNSQL_MATCHED_SEED).sample(range(total), n))
    items = []
    with SYNSQL_POOL_JSONL_PATH.open() as f:
        for i, line in enumerate(f):
            if i in want and line.strip():
                items.append(json.loads(line))
    return items


def _load_synsql_matched_pool(n: int) -> list[dict]:
    if SYNSQL_MATCHED_POOL_PATH.exists():
        with SYNSQL_MATCHED_POOL_PATH.open() as f:
            items = [json.loads(l) for l in f if l.strip()]
        if len(items) == n:
            return items
    items = _build_synsql_matched_pool(n)
    SYNSQL_MATCHED_POOL_PATH.parent.mkdir(parents=True, exist_ok=True)
    with SYNSQL_MATCHED_POOL_PATH.open("w") as f:
        for it in items:
            f.write(json.dumps(it) + "\n")
    return items


def _build_synsql_matched_hard_pool(n: int) -> list[dict]:
    """Same streaming-sample pattern as _build_synsql_matched_pool, but reads
    the Hard+Extra-Hard-filtered pool (SYNSQL_HARD_POOL_JSONL_PATH, built by
    build_synsql_hard_pool.py) instead of the full 2.5M pool."""
    import random

    if not SYNSQL_HARD_POOL_JSONL_PATH.exists():
        raise RuntimeError(
            f"{SYNSQL_HARD_POOL_JSONL_PATH} not found - run "
            "`python3 data_bird/build_synsql_hard_pool.py` first.")
    with SYNSQL_HARD_POOL_JSONL_PATH.open() as f:
        total = sum(1 for _ in f)
    n = min(n, total)
    want = set(random.Random(SYNSQL_MATCHED_HARD_SEED).sample(range(total), n))
    items = []
    with SYNSQL_HARD_POOL_JSONL_PATH.open() as f:
        for i, line in enumerate(f):
            if i in want and line.strip():
                items.append(json.loads(line))
    return items


def _load_synsql_matched_hard_pool(n: int) -> list[dict]:
    """Cache read/write for the hard-only matched pool. Unlike
    _load_synsql_matched_pool (which only checks len(items)==n - a known,
    deliberately-not-retrofitted gap), also validates a sidecar meta file
    recording {n, seed} so switching SYNSQL_MATCHED_HARD_SEED can never
    silently reuse a stale cache."""
    meta = {"n": n, "seed": SYNSQL_MATCHED_HARD_SEED}
    if SYNSQL_MATCHED_HARD_POOL_PATH.exists() and SYNSQL_MATCHED_HARD_POOL_META_PATH.exists():
        cached_meta = json.loads(SYNSQL_MATCHED_HARD_POOL_META_PATH.read_text())
        if cached_meta == meta:
            with SYNSQL_MATCHED_HARD_POOL_PATH.open() as f:
                items = [json.loads(l) for l in f if l.strip()]
            if len(items) == meta["n"]:
                return items
    items = _build_synsql_matched_hard_pool(n)
    SYNSQL_MATCHED_HARD_POOL_PATH.parent.mkdir(parents=True, exist_ok=True)
    with SYNSQL_MATCHED_HARD_POOL_PATH.open("w") as f:
        for it in items:
            f.write(json.dumps(it) + "\n")
    SYNSQL_MATCHED_HARD_POOL_META_PATH.write_text(
        json.dumps({"n": len(items), "seed": SYNSQL_MATCHED_HARD_SEED}))
    return items


class _Pool:
    """One embedding-indexed pool (train or hard)."""

    def __init__(self, name: str, items: list[dict], embedder: SentenceTransformer,
                 src_mtime: float):
        self.items = items
        CACHE_DIR.mkdir(exist_ok=True)
        cache_path = CACHE_DIR / f"{name}_embeddings.pt"
        if cache_path.exists() and cache_path.stat().st_mtime >= src_mtime:
            self.embeddings = torch.load(cache_path)
        else:
            self.embeddings = embedder.encode(
                [it["question"] for it in items], convert_to_tensor=True,
                normalize_embeddings=True, show_progress_bar=True)
            torch.save(self.embeddings, cache_path)

    def top_k(self, query_emb: torch.Tensor, k: int, exclude_exact: str,
              db_id: "str | None" = None) -> list[dict]:
        scores = torch.mv(self.embeddings, query_emb.to(self.embeddings.device)).clone()
        qn = _norm(exclude_exact)
        for i, it in enumerate(self.items):
            if _norm(it["question"]) == qn:
                scores[i] = float("-inf")
                continue
            if db_id is not None and it.get("db_id") != db_id:
                scores[i] = float("-inf")
        idx = torch.topk(scores, min(k, len(self.items))).indices.tolist()
        return [self.items[i] for i in idx]


class Retriever:
    """Build once, then call .retrieve(question) many times."""

    def __init__(self, embed_model: str = EMBED_MODEL_NAME):
        self.embedder = SentenceTransformer(embed_model, device=_best_device())
        src_mtime = max(TRAIN_PATH.stat().st_mtime,
                        *(p.stat().st_mtime for p in HARD_POOL_PATHS))
        self.train_pool = _Pool("train", _load_train(), self.embedder, src_mtime)
        self.hard_pool = _Pool("hard", _load_hard(), self.embedder, src_mtime)
        self._synsql_index = None
        self._synsql_items: "list[dict] | None" = None
        self._synsql_topk_cache: "dict[str, list[dict]] | None" = None
        self._synsql_matched_pool: "_Pool | None" = None
        self._synsql_matched_hard_pool: "_Pool | None" = None

    def retrieve(self, question: str, k_train: int = K_TRAIN,
                 k_hard: int = K_HARD) -> tuple[list[dict], list[dict]]:
        """Returns (train_exemplars, hard_exemplars) for one dev question."""
        q_emb = self.embedder.encode([question], convert_to_tensor=True,
                                      normalize_embeddings=True)[0]
        train_ex = self.train_pool.top_k(q_emb, k_train, exclude_exact=question)
        hard_ex = self.hard_pool.top_k(q_emb, k_hard, exclude_exact=question)
        return train_ex, hard_ex

    def retrieve_hard_same_db(self, question: str, db_id: str, k: int = 5) -> list[dict]:
        """Returns k hard-pool exemplars from the SAME db_id as the question,
        ranked by embedding similarity - no train exemplars. Use this when the
        question's own db_id is one the hard pool covers (train and dev/hard
        use disjoint db_id sets, so train exemplars are never same-schema)."""
        q_emb = self.embedder.encode([question], convert_to_tensor=True,
                                      normalize_embeddings=True)[0]
        return self.hard_pool.top_k(q_emb, k, exclude_exact=question, db_id=db_id)

    def retrieve_hard_any_db(self, question: str, k: int = 5) -> list[dict]:
        """Returns k hard-pool exemplars from ANY db_id (whole pool), ranked by
        embedding similarity. Used for the cross-/whole-pool few-shot setting
        where the test schema has no dedicated exemplar pool; each returned
        exemplar carries its own db_id so its schema can be attached."""
        q_emb = self.embedder.encode([question], convert_to_tensor=True,
                                      normalize_embeddings=True)[0]
        return self.hard_pool.top_k(q_emb, k, exclude_exact=question)

    def retrieve_synsql(self, question: str, k: int = K_SYNSQL) -> list[dict]:
        """Returns k nearest exemplars from the full SynSQL-2.5M pool (an
        external synthetic text-to-SQL dataset, unrelated to BIRD) instead of
        the train/hard pools - isolates whether few-shot gains come from
        BIRD-specific exemplars or from any semantically-relevant
        (question, SQL) pair. Checks the precomputed top-k cache first (see
        data_bird/build_synsql_topk_cache.py - covers every BIRD dev question)
        so a repeat run never has to load the FAISS index / embedder or
        search again; only an unseen question falls through to a live FAISS
        search (see data_bird/build_synsql_index.py, run once beforehand)."""
        if self._synsql_topk_cache is None:
            if SYNSQL_TOPK_CACHE_PATH.exists():
                self._synsql_topk_cache = json.loads(SYNSQL_TOPK_CACHE_PATH.read_text())
            else:
                self._synsql_topk_cache = {}
        cached = self._synsql_topk_cache.get(_norm(question))
        if cached is not None:
            return cached[:k]

        if self._synsql_index is None:
            import faiss
            if not SYNSQL_FAISS_INDEX_PATH.exists():
                raise RuntimeError(
                    "SynSQL FAISS index not found at "
                    f"{SYNSQL_FAISS_INDEX_PATH} - run "
                    "`python3 data_bird/build_synsql_index.py` first "
                    "(one-time: downloads all ~2.5M rows and embeds them, "
                    "~1-2 hours).")
            self._synsql_index = faiss.read_index(str(SYNSQL_FAISS_INDEX_PATH))
            self._synsql_items = load_synsql_pool()
            if self._synsql_index.ntotal != len(self._synsql_items):
                raise RuntimeError(
                    f"synsql FAISS index ({self._synsql_index.ntotal} vectors) and "
                    f"pool jsonl ({len(self._synsql_items)} rows) are out of sync - "
                    "rebuild with data_bird/build_synsql_index.py")
        q_emb = self.embedder.encode([question], convert_to_numpy=True,
                                      normalize_embeddings=True).astype("float32")
        qn = _norm(question)
        _, idx = self._synsql_index.search(q_emb, k + 1)
        out = []
        for i in idx[0]:
            if i < 0:
                continue
            item = self._synsql_items[i]
            if _norm(item["question"]) == qn:
                continue
            out.append(item)
            if len(out) >= k:
                break
        return out

    def retrieve_hard_cross_db(self, question: str, exclude_db: str, k: int = 5) -> list[dict]:
        """Returns the k nearest hard-pool exemplars EXCLUDING the question's own
        database (true cross-schema / unseen-test-schema setting). Schemas may
        repeat among the k (only exclude_db is removed). Over-fetches then drops
        same-db entries and keeps the top k."""
        q_emb = self.embedder.encode([question], convert_to_tensor=True,
                                      normalize_embeddings=True)[0]
        cand = self.hard_pool.top_k(q_emb, k * 12, exclude_exact=question)
        return [e for e in cand if e.get("db_id") != exclude_db][:k]

    def retrieve_synsql_matched(self, question: str, k: int = K_SYNSQL) -> list[dict]:
        """k nearest exemplars from a SynSQL subsample the SAME SIZE as the
        BIRD hard pool (826) - the size-matched control for retrieve_synsql.
        Built once (lazy), cached to disk (data_bird/synsql/
        synsql_matched_pool.jsonl) and as embeddings (judge/cache/
        synsql_matched_embeddings.pt) so this is cheap after the first call."""
        if self._synsql_matched_pool is None:
            n = len(load_hard_pool())
            items = _load_synsql_matched_pool(n)
            src_mtime = SYNSQL_MATCHED_POOL_PATH.stat().st_mtime
            self._synsql_matched_pool = _Pool("synsql_matched", items, self.embedder, src_mtime)
        q_emb = self.embedder.encode([question], convert_to_tensor=True,
                                      normalize_embeddings=True)[0]
        return self._synsql_matched_pool.top_k(q_emb, k, exclude_exact=question)

    def retrieve_synsql_matched_hard(self, question: str, k: int = K_SYNSQL) -> list[dict]:
        """k nearest exemplars from a SynSQL subsample the SAME SIZE as the
        BIRD hard pool (826), sampled ONLY from rows whose SQL classifies as
        Hard/Extra-Hard (see sql_hardness.py, build_synsql_hard_pool.py) -
        isolates whether exemplar SQL complexity, not just pool size, drives
        synsql_fewshot_matched's edge. Built once (lazy), cached to disk
        (data_bird/synsql/synsql_matched_hard_pool.jsonl) and as embeddings
        (judge/cache/synsql_matched_hard_embeddings.pt), independent of the
        non-hard matched pool's caches."""
        if self._synsql_matched_hard_pool is None:
            n = len(load_hard_pool())
            items = _load_synsql_matched_hard_pool(n)
            src_mtime = SYNSQL_MATCHED_HARD_POOL_PATH.stat().st_mtime
            self._synsql_matched_hard_pool = _Pool(
                "synsql_matched_hard", items, self.embedder, src_mtime)
        q_emb = self.embedder.encode([question], convert_to_tensor=True,
                                      normalize_embeddings=True)[0]
        return self._synsql_matched_hard_pool.top_k(q_emb, k, exclude_exact=question)
