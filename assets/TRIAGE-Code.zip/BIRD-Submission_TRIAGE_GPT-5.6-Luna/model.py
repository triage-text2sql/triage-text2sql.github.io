"""
model.py — Unified LLM backend for BOTH the BIRD and Spider NL2SQL pipelines.

Every LLM generation call in either pipeline goes through the `AsyncCaller`
class defined here. Which backend actually serves the call is chosen ONCE, at
process start, by the environment variable MODEL_BACKEND:

  MODEL_BACKEND=proxy   (default)
      Calls the OpenAI Responses API (model "gpt-5.6-luna") using the API key
      in OPENAI_API_KEY. A synchronous call_model is run in a thread pool,
      semaphore-bounded, with retry/backoff. This is the path the submission
      run uses.

  MODEL_BACKEND=local
      Loads a local HuggingFace causal LM by name (MODEL_NAME, default a small
      Qwen) via `transformers` (AutoModelForCausalLM + AutoTokenizer, using the
      tokenizer's chat template) and generates from a list-of-messages prompt.
      The model is loaded lazily on the first call and reused. Generation is
      synchronous under the hood but wrapped in asyncio.to_thread so the SAME
      `await caller(messages)` interface works unchanged.

      NOTE ON VL MODELS: the default MODEL_NAME points at a small Qwen model.
      If you set MODEL_NAME to a *-VL (vision-language) checkpoint, it is used
      TEXT-ONLY here — the pipelines only ever send text chat messages, so the
      vision tower is never exercised. A plain text Qwen (e.g.
      Qwen/Qwen2.5-0.5B-Instruct) is recommended and will load faster.

Public interface (what the pipelines import):
    from model import AsyncCaller                # both pipelines
    caller = AsyncCaller(model_alias=..., max_concurrency=..., max_tokens=...)
    text   = await caller([{"role": "system", ...}, {"role": "user", ...}])

Also exported for the copied helper modules:
    resolve_model, call_model, ALL_MODELS        # proxy-transport compatibility
    gather_with_progress                         # ordered concurrent gather + tqdm

Config summary (environment variables):
    MODEL_BACKEND   proxy | local           (default: proxy)
    MODEL_NAME      HF model id             (local backend; default small Qwen)
    MAX_TOKENS      default max_new_tokens  (fallback when a caller passes none)
    OPENAI_API_KEY                                 (proxy backend)
"""
from __future__ import annotations

import asyncio
import os
from pathlib import Path

try:
    from dotenv import load_dotenv
    # Load the package-root .env (this file's directory) if present.
    load_dotenv(Path(__file__).resolve().parent / ".env")
    load_dotenv()  # also respect a CWD .env / already-exported vars
except Exception:
    pass

MODEL_BACKEND = os.environ.get("MODEL_BACKEND", "proxy").strip().lower()
# Default to a small text Qwen; a *-VL model works too (text-only, see docstring).
MODEL_NAME = os.environ.get("MODEL_NAME", "Qwen/Qwen2.5-0.5B-Instruct")
DEFAULT_MAX_TOKENS = int(os.environ.get("MAX_TOKENS", "1500"))


# ─────────────────────────────────────────────────────────────────────────────
# PROXY BACKEND — OpenAI Responses API (model: gpt-5.6-luna)
# ─────────────────────────────────────────────────────────────────────────────
_API_KEY = os.environ.get("OPENAI_API_KEY", "")

# The proxy backend serves exactly one hosted model.
PROXY_MODEL = "gpt-5.6-luna"
# Kept as a list for the import surface the copied helper modules expect.
ALL_MODELS = [PROXY_MODEL]

_PROXY_CLIENT = None


def resolve_model(alias_or_name: str = PROXY_MODEL) -> str:
    """The proxy backend uses a single fixed model, so any alias resolves to it."""
    return PROXY_MODEL


def _proxy_client():
    global _PROXY_CLIENT
    if _PROXY_CLIENT is None:
        from openai import OpenAI
        _PROXY_CLIENT = OpenAI(
            api_key=_API_KEY or "placeholder",
            timeout=300.0,
        )
    return _PROXY_CLIENT


def call_model(model_name: str = PROXY_MODEL, messages: "list | None" = None,
               max_tokens: int = 1024) -> str:
    """Synchronous proxy call via the OpenAI Responses API. The proxy backend
    serves one model (gpt-5.6-luna); `model_name` is accepted for interface
    compatibility but ignored, as is `max_tokens` (the reasoning model manages
    its own output budget)."""
    if not _API_KEY:
        raise EnvironmentError(
            "MODEL_BACKEND=proxy requires OPENAI_API_KEY. Set it in the "
            "environment (export OPENAI_API_KEY=...) or in .env."
        )
    resp = _proxy_client().responses.create(
        model=PROXY_MODEL,
        input=messages,
        reasoning={"effort": "medium"},
    )
    return resp.output_text


# ─────────────────────────────────────────────────────────────────────────────
# LOCAL BACKEND — HuggingFace causal LM via transformers
# ─────────────────────────────────────────────────────────────────────────────
_LOCAL = {"tok": None, "model": None, "name": None}


def _load_local(model_name: str):
    """Lazy-load and cache the local HF model + tokenizer. Raises a clear,
    actionable error if `transformers`/`torch` (or the model) are unavailable."""
    if _LOCAL["model"] is not None and _LOCAL["name"] == model_name:
        return _LOCAL["tok"], _LOCAL["model"]
    try:
        import torch  # noqa: F401
        from transformers import AutoModelForCausalLM, AutoTokenizer
    except Exception as e:  # ImportError or partial install
        raise RuntimeError(
            "MODEL_BACKEND=local needs `transformers` and `torch` installed "
            "(`pip install transformers torch`). Import failed with: "
            f"{type(e).__name__}: {e}"
        ) from e
    try:
        import torch
        tok = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
        dtype = "auto"
        device_map = "auto" if torch.cuda.is_available() else None
        model = AutoModelForCausalLM.from_pretrained(
            model_name, torch_dtype=dtype, device_map=device_map,
            trust_remote_code=True)
        if device_map is None:
            model = model.to("cuda" if torch.cuda.is_available()
                             else ("mps" if torch.backends.mps.is_available() else "cpu"))
        model.eval()
    except Exception as e:
        raise RuntimeError(
            f"MODEL_BACKEND=local failed to load MODEL_NAME='{model_name}'. "
            "Set MODEL_NAME to an available small text model (e.g. "
            "'Qwen/Qwen2.5-0.5B-Instruct') and ensure it can be downloaded or "
            f"is cached locally. Underlying error: {type(e).__name__}: {e}"
        ) from e
    _LOCAL.update(tok=tok, model=model, name=model_name)
    return tok, model


def _generate_local(messages: list, max_tokens: int, model_name: str) -> str:
    import torch
    tok, model = _load_local(model_name)
    # Use the model's own chat template when available; otherwise fall back to a
    # simple role-tagged concatenation.
    if getattr(tok, "chat_template", None):
        prompt = tok.apply_chat_template(messages, tokenize=False,
                                         add_generation_prompt=True)
    else:
        prompt = "\n\n".join(f"{m['role'].upper()}: {m['content']}"
                             for m in messages) + "\n\nASSISTANT:"
    inputs = tok(prompt, return_tensors="pt").to(model.device)
    with torch.no_grad():
        out = model.generate(**inputs, max_new_tokens=max_tokens,
                             do_sample=False, pad_token_id=tok.eos_token_id)
    gen = out[0][inputs["input_ids"].shape[1]:]
    return tok.decode(gen, skip_special_tokens=True)


# ─────────────────────────────────────────────────────────────────────────────
# UNIFIED ASYNC INTERFACE — the single class both pipelines import
# ─────────────────────────────────────────────────────────────────────────────
class AsyncCaller:
    """Build once per model, then `await caller(messages)` many times.

    Interface-compatible with the original judge/llm_call.AsyncCaller so the
    copied pipeline code needs only `from model import AsyncCaller` (via the
    thin llm_call.py shim in each sub-package). The proxy path is concurrent
    (semaphore-bounded threads); the local path runs one generation at a time
    under the hood but exposes the identical awaitable interface.
    """

    # Deterministic 4xx errors won't improve on retry — fail fast (proxy path).
    _NON_RETRYABLE = ("contextwindowexceeded", "prompt is too long",
                      "context window", "context_length_exceeded")

    def __init__(self, model_alias: str = PROXY_MODEL, max_concurrency: int = 8,
                 max_retries: int = 5, max_tokens: int = DEFAULT_MAX_TOKENS):
        self.backend = MODEL_BACKEND
        self.model = resolve_model(model_alias)
        self.max_tokens = max_tokens
        self.max_retries = max_retries
        # Local generation is single-model / not thread-safe for concurrent
        # .generate() calls, so force serial there; proxy honors the cap.
        self._sem = asyncio.Semaphore(1 if self.backend == "local" else max_concurrency)

    async def __call__(self, messages: list) -> str:
        if self.backend == "local":
            async with self._sem:
                return await asyncio.to_thread(
                    _generate_local, messages, self.max_tokens, MODEL_NAME)

        # proxy backend (default): thread-offloaded synchronous call + backoff
        last_err = None
        async with self._sem:
            for attempt in range(self.max_retries):
                try:
                    return await asyncio.to_thread(
                        call_model, self.model, messages, self.max_tokens)
                except Exception as e:
                    last_err = e
                    if any(s in str(e).lower() for s in self._NON_RETRYABLE):
                        break
                    await asyncio.sleep(min(2 ** attempt * 2, 60))
        raise RuntimeError(
            f"LLM call to {self.model} failed after {self.max_retries} "
            f"retries: {last_err}")


async def gather_with_progress(coros, desc: str = ""):
    """Run coroutines concurrently; return results IN ORDER, with a tqdm bar.
    (Verbatim behavior of the original llm_call.gather_with_progress.)"""
    from tqdm import tqdm
    results = [None] * len(coros)

    async def _wrap(i, c):
        results[i] = await c

    tasks = [asyncio.create_task(_wrap(i, c)) for i, c in enumerate(coros)]
    for fut in tqdm(asyncio.as_completed(tasks), total=len(tasks), desc=desc, ncols=80):
        await fut
    return results
