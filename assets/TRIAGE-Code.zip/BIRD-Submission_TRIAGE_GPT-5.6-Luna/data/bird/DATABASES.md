# BIRD databases — where to place the SQLite files

The BIRD dev SQLite databases are large (hundreds of MB total) and are **not**
shipped in this package. 

For development purpose, place each dev database's `.sqlite` file exactly here:

```
data/bird/dev/dev_databases/<db_id>/<db_id>.sqlite
```

For official test purpose, place each test database's `.sqlite` file exactly here:

```
data/bird/test/test_databases/<db_id>/<db_id>.sqlite
```

For example:

```
data/bird/dev/dev_databases/california_schools/california_schools.sqlite
data/bird/dev/dev_databases/financial/financial.sqlite
data/bird/dev/dev_databases/superhero/superhero.sqlite
...
```

Optionally, each database directory may also contain a
`database_description/<table>.csv` folder (BIRD's per-column descriptions). If
present, those descriptions are rendered into the prompt schema; if absent,
the schema still renders (just without column descriptions).

## Where to get them
- Official BIRD dev release: <https://bird-bench.github.io/> (download the dev
  set, unzip `dev_databases.zip`, and move the `dev_databases/` tree here).
- Or copy from the source repo used to build this package:
  `OIA-experiments-error-BIRD/data_bird/dev/dev_databases/`.

## What ships in this package
- `dev/dev.json`, `dev/dev_tables.json` — questions + schema metadata (present).
- `train/train.json`, `train/train_tables.json` — used only for the
  schema-predictor's few-shot exemplars (present).
- `hard/*.jsonl`, `schema_graphs.json` — hard-pool + join-graph metadata (present).
- **No databases are included** — place them yourself (dev tree above; test
  databases under the `db_dir` from `submission_config.yaml`, i.e.
  `data/bird/test/test_databases/<db_id>/<db_id>.sqlite`, or set `BIRD_DB_DIR`).

Execution accuracy is scored by running the predicted SQL against these
`.sqlite` files, so a database must be present for its questions to be scored.
The code resolves DB paths via `bird/execution.py:db_path_for()` and
`bird/selector_tier1.py:_connect()`, both rooted at `data/bird/dev/dev_databases/`.
